ParcelGuard PC V1.4.0 PILOT BUILD PACKAGE

The Windows EXE/installer has NOT been compiled yet.
To build: put the contents of this folder into a SEPARATE GitHub branch feature/windows-installer-v1.4.0 (do not replace production branches), then run GitHub Actions workflow build-installer.yml.
Alternatively on Windows, open pc-installer/BUILD-WINDOWS.bat and compile pc-installer/installer/ParcelGuard.iss with Inno Setup.
Backups are stored in %%LOCALAPPDATA%%\ParcelGuardPC-Backups. Pilot uses %%LOCALAPPDATA%%\ParcelGuardPC-Pilot-V130 and never overwrites Stable directory %%LOCALAPPDATA%%\ParcelGuardPC.
