import base64
import io
import json
import tempfile
import time
import urllib.error
import urllib.request
import unittest
import zipfile
import hashlib
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from server import Store,start

class StationTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory()
        self.s=Store(self.temp.name)
        self.jpg='data:image/jpeg;base64,'+base64.b64encode(b'\xff\xd8DEMO\xff\xd9').decode()
        self.webm='data:video/webm;base64,'+base64.b64encode(b'\x1a\x45\xdf\xa3DEMO').decode()
    def tearDown(self):self.s.close();self.temp.cleanup()
    def test_usb_input_creates_bag_tracking_image_and_video(self):
        r=self.s.pc_scan('SPX001','BAG-PC-01','SPX',self.jpg,self.webm)
        self.assertEqual(r['imported'],1)
        row=self.s.parcels()[0]
        self.assertTrue(self.s.media_location(row['photo_sha']).exists())
        self.assertTrue(self.s.media_location(row['video_sha']).exists())
        self.assertEqual(row['bag_id'],'BAG-PC-01')
    def test_duplicate_pc_scan_does_not_overwrite(self):
        self.s.pc_scan('SPX001','BAG-PC-01','SPX',self.jpg)
        with self.assertRaisesRegex(ValueError,'สแกนบน PC แล้ว'):
            self.s.pc_scan('SPX001','BAG-PC-01','SPX',self.jpg)
        self.assertEqual(len(self.s.parcels()),1)
    def test_invalid_image_rejected(self):
        with self.assertRaisesRegex(ValueError,'JPEG'):
            self.s.pc_scan('SPX002','BAG-PC-01','SPX','data:image/jpeg;base64,'+base64.b64encode(b'not an image').decode())
        self.assertEqual(len(self.s.parcels()),0)

if __name__=='__main__':unittest.main()
