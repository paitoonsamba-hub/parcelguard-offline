import unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
JS=(ROOT/'web/app.js').read_text(encoding='utf-8')
CSS=(ROOT/'web/styles.css').read_text(encoding='utf-8')
class BagAuditUiTests(unittest.TestCase):
    def test_review_badge_counts_actual_scans(self):
        self.assertIn("pill(b.scanned.length+' รายการ','blue')", JS)
        self.assertNotIn("pill('ไม่มีรายการ','amber')", JS)
    def test_popup_uses_actual_scanned_records(self):
        popup=JS.split('function openBag(key){',1)[1].split('function openEvidence(',1)[0]
        self.assertIn('const scans=b.scanned||[];', popup)
        self.assertIn('scans.map((tracking,i)', popup)
        self.assertIn('ยังไม่มีรายการพัสดุในถุงนี้', popup)
        self.assertIn('esc(tracking)', popup)
    def test_print_same_selected_bag(self):
        popup=JS.split('function openBag(key){',1)[1].split('function openEvidence(',1)[0]
        self.assertIn('data-printbag=', popup)
        self.assertIn('esc(b.key)', popup)
        self.assertIn("window.open('/print-bag.html?bag='+encodeURIComponent(pb.dataset.printbag)", JS)
    def test_modal_scrolling_for_long_bags(self):
        self.assertIn('max-height:290px', CSS)
        self.assertIn('overflow-y:auto', CSS)
if __name__=='__main__': unittest.main()
