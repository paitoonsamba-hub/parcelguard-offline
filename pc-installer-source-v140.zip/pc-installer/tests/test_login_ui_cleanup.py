import unittest
from pathlib import Path
class LoginUiCleanupTest(unittest.TestCase):
 def test_email_focus_button_removed_without_breaking_submit(self):
  base=Path(__file__).resolve().parents[1]/"web"
  html=(base/"login.html").read_text(encoding="utf8")
  js=(base/"login.js").read_text(encoding="utf8")
  self.assertNotIn("focus-email",html+js)
  self.assertNotIn("กรอกอีเมล</button>",html)
  self.assertIn('id="email"',html)
  self.assertIn('id="password"',html)
  self.assertIn('id="send"',html)
  self.assertIn("fetch('/api/auth/login'",js)
  self.assertIn("window.location.replace('/')",js)
