import json
import sys
import tempfile
import threading
import unittest
import urllib.error
import urllib.request
from pathlib import Path
from unittest.mock import patch
from http.server import ThreadingHTTPServer
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from server import Store,make_handler,SESSIONS,AUTH_LOCK

class LoginBrowserAssetTests(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory()
  self.store=Store(self.tmp.name)
  self.server=ThreadingHTTPServer(('127.0.0.1',0),make_handler(self.store,'local'))
  self.server.lan_enabled=False
  self.worker=threading.Thread(target=self.server.serve_forever,daemon=True)
  self.worker.start()
  self.url=f'http://127.0.0.1:{self.server.server_port}'
 def tearDown(self):
  self.server.shutdown();self.server.server_close();self.worker.join(timeout=3)
  self.store.close();self.tmp.cleanup()
  with AUTH_LOCK:SESSIONS.clear()
 def test_login_js_served_under_strict_csp(self):
  with urllib.request.urlopen(self.url+'/login.html') as r:
   html=r.read().decode();csp=r.headers['Content-Security-Policy']
  self.assertIn('<script src="/login.js" defer></script>',html)
  self.assertNotIn('<script>',html)
  self.assertIn("script-src 'self'",csp)
  with urllib.request.urlopen(self.url+'/login.js') as r:
   self.assertEqual(r.status,200)
   self.assertIn('javascript',r.headers['Content-Type'])
   js=r.read().decode()
  self.assertIn("fetch('/api/auth/login'",js)
 def test_fake_pro_signin_redirect_session_route(self):
  with patch('server.verify_commercial_login',return_value={'email':'test@example.com','idToken':'fake','refreshToken':'fake','deviceHash':'a'*64,'tokenExpires':999999999.0}):
   request=urllib.request.Request(self.url+'/api/auth/login',data=json.dumps({'email':'test@example.com','password':'test'}).encode(),headers={'Content-Type':'application/json','Origin':self.url,'Sec-Fetch-Site':'same-origin'})
   with urllib.request.urlopen(request) as r:
    self.assertEqual(r.status,200)
    cookie=r.headers.get('Set-Cookie').split(';')[0]
  with urllib.request.urlopen(urllib.request.Request(self.url+'/',headers={'Cookie':cookie})) as r:
   page=r.read().decode()
   self.assertEqual(r.status,200)
   self.assertIn('ParcelGuard',page)
   self.assertNotIn('example@gmail.com',page)
if __name__=='__main__':unittest.main()
