import hashlib
import io
from pathlib import Path
import sys
import tempfile
import unittest
import zipfile

sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from server import Store, parse_csv_bytes, make_handler


def evidence_zip(tracks=('SPX000012345','SPX000012346'), photo=b'fake jpeg', corrupt=False):
    output=io.BytesIO()
    with zipfile.ZipFile(output,'w',compression=zipfile.ZIP_DEFLATED) as z:
        lines=['tracking,bag,photo_name,scanned_at,video_offset_ms,parcel_video_file,video_status']
        for i,tracking in enumerate(tracks):
            lines.append(f'"{tracking}","BAG-TEST","photos/{tracking}.jpg",1762010000000,-1,"",0')
            z.writestr(f'photos/{tracking}.jpg', photo+str(i).encode())
        z.writestr('manifest.csv','\n'.join(lines))
        ch=hashlib.sha256(photo+b'0').hexdigest()
        z.writestr('SHA256SUMS.txt',f"{'0'*64 if corrupt else ch}  photos/{tracks[0]}.jpg\n")
    return output.getvalue()


class TestParcelGuard(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.store=Store(self.tmp.name)
    def tearDown(self):
        self.store.close();self.tmp.cleanup()
    def test_expected_leading_zero_and_duplicate_rejected(self):
        self.assertEqual(parse_csv_bytes(b'tracking\n000123\n000124\n','expected'),['000123','000124'])
        with self.assertRaises(ValueError): parse_csv_bytes(b'tracking\n000123\n000123\n','expected')
    def test_android_zip_roundtrip_idempotent(self):
        raw=evidence_zip()
        r=self.store.ingest_zip(raw)
        self.assertEqual(r['imported'],2)
        self.assertEqual(self.store.ingest_zip(raw)['skipped'],2)
        self.assertEqual(len(self.store.parcels()),2)
        bag=self.store.bags()[0]
        self.assertEqual(bag['bag_id'],'BAG-TEST')
        self.assertFalse(bag['verified'])
        self.assertTrue(self.store.media_location(self.store.parcels()[0]['photo_sha']).exists())
    def test_manifest_comparison(self):
        self.store.ingest_zip(evidence_zip())
        bag=self.store.bags()[0]
        self.store.set_expected(bag['key'],b'tracking\nSPX000012345\nSPX000012347\n')
        b=self.store.bags()[0]
        self.assertEqual(b['missing'],['SPX000012347'])
        self.assertEqual(b['extra'],['SPX000012346'])
        self.assertFalse(b['verified'])
        self.store.set_expected(b['key'],b'tracking\nSPX000012345\nSPX000012346\n')
        self.assertTrue(self.store.bags()[0]['verified'])
    def test_corrupt_checksum_does_not_save(self):
        with self.assertRaises(ValueError):self.store.ingest_zip(evidence_zip(corrupt=True))
        self.assertEqual(len(self.store.parcels()),0)
    def test_unsafe_zip_rejected(self):
        output=io.BytesIO()
        with zipfile.ZipFile(output,'w') as z:
            z.writestr('manifest.csv','tracking,bag,photo_name,scanned_at\nSPX001,BAG-TEST,photos/SPX001.jpg,1762010000000')
            z.writestr('../evil.txt','evil')
        with self.assertRaises(ValueError):self.store.ingest_zip(output.getvalue())
    def test_device_token(self):
        pair=self.store.connect_device('Vivo V29')
        self.assertEqual(self.store.auth_device(pair['token']),pair['id'])
        self.assertIsNone(self.store.auth_device('something-else'))
        self.assertNotIn('token',str(self.store.devices()))

if __name__=='__main__':unittest.main()
