import sys, tempfile, sqlite3, pathlib, unittest
sys.path.insert(0,str(pathlib.Path(__file__).resolve().parents[1]))
from server import Store, APP_VERSION, UPDATE_MANIFEST_URL
class InstallerBackupTests(unittest.TestCase):
    def test_online_backup_copies_sqlite_and_media_and_identity(self):
        with tempfile.TemporaryDirectory() as d:
            root=pathlib.Path(d); live=root/'live'; backup=root/'backups'
            store=Store(live)
            try:
                store.create_test_bag('BAG-A01','SPX')
                (live/'commercial-device-id').write_text('123')
                (live/'media'/'sample.jpg').write_bytes(b'JPEG TEST')
                result=store.backup_now(backup)
                out=pathlib.Path(result['backup_dir'])
                self.assertEqual(result['ok'],True)
                self.assertEqual((out/'media'/'sample.jpg').read_bytes(),b'JPEG TEST')
                self.assertEqual((out/'commercial-device-id').read_text(),'123')
                with sqlite3.connect(out/'parcelguard-pc.sqlite3') as saved:
                    self.assertEqual(saved.execute('select count(*) from bags').fetchone()[0],1)
                    self.assertEqual(saved.execute('pragma integrity_check').fetchone()[0],'ok')
                self.assertTrue((live/'parcelguard-pc.sqlite3').is_file())
            finally:
                store.close()
    def test_remote_update_is_read_only_and_version_is_explicit(self):
        self.assertEqual(APP_VERSION,'1.4.0')
        self.assertTrue(UPDATE_MANIFEST_URL.startswith('https://parcelguard-license.web.app/'))
if __name__=='__main__': unittest.main()
