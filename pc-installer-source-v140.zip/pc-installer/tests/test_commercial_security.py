import tempfile,time,unittest
from pathlib import Path
from unittest.mock import patch
from server import pc_device_hash,verify_commercial_login,refresh_commercial_session,new_session,session_for,AUTH_LOCK,SESSIONS

class CommercialSecurityTests(unittest.TestCase):
    def tearDown(self):
        with AUTH_LOCK: SESSIONS.clear()
    def test_device_hash_is_stable_and_unique(self):
        with tempfile.TemporaryDirectory() as a, tempfile.TemporaryDirectory() as b:
            self.assertEqual(pc_device_hash(a),pc_device_hash(a))
            self.assertNotEqual(pc_device_hash(a),pc_device_hash(b))
            self.assertEqual(len(pc_device_hash(a)),64)
    def test_login_denies_mobile_license(self):
        with tempfile.TemporaryDirectory() as d,patch('server.firebase_post') as remote:
            remote.side_effect=[{'idToken':'token','refreshToken':'refresh','email':'demo@example.com','expiresIn':'3600'}, {'result':{'authorized':False,'plan':'android'}}]
            with self.assertRaises(ValueError):verify_commercial_login('demo@example.com','pw',d)
    def test_revoked_remote_check_closes_existing_session(self):
        creds={'idToken':'id','refreshToken':'refresh','tokenExpires':time.monotonic()+1000,'deviceHash':'a'*64}
        token,record=new_session('demo@example.com',creds)
        record['next_check']=0
        with patch('server.commercial_check',side_effect=ValueError('revoked')):
            self.assertIsNone(session_for('pg_session='+token))
    def test_recheck_success_keeps_session(self):
        creds={'idToken':'id','refreshToken':'refresh','tokenExpires':time.monotonic()+1000,'deviceHash':'a'*64}
        token,record=new_session('demo@example.com',creds)
        record['next_check']=0
        with patch('server.commercial_check',return_value={'authorized':True,'plan':'pro'}):
            self.assertIsNotNone(session_for('pg_session='+token))
            self.assertGreater(record['next_check'],time.monotonic())

if __name__=='__main__':unittest.main()
