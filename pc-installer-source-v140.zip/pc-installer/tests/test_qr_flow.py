import json
import sys
import tempfile
import threading
import time
import unittest
import urllib.error
import urllib.request
from http.server import ThreadingHTTPServer
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from server import Store, make_handler, QR_LOCK, QR_STATE, new_session, SESSIONS, AUTH_LOCK

class QRFlowTests(unittest.TestCase):
    def setUp(self):
        self.cookie,self.session=new_session('owner@example.test')
        self.folder=tempfile.TemporaryDirectory()
        self.store=Store(self.folder.name)
        self.local=ThreadingHTTPServer(('127.0.0.1',0),make_handler(self.store,'local'))
        self.local.lan_enabled=True
        self.lan=ThreadingHTTPServer(('127.0.0.1',0),make_handler(self.store,'lan'))
        self.threads=[]
        for server in (self.local,self.lan):
            thread=threading.Thread(target=server.serve_forever,daemon=True)
            thread.start();self.threads.append(thread)
    def tearDown(self):
        for server in (self.local,self.lan):
            server.shutdown();server.server_close()
        for thread in self.threads:thread.join(timeout=3)
        self.store.close();self.folder.cleanup()
        with QR_LOCK:QR_STATE.update(code='',until=0,last_result='test cleaned')
        with AUTH_LOCK:SESSIONS.clear()
    def req(self,base,path,data=None):
        url=f'http://127.0.0.1:{base.server_port}{path}'
        raw=None if data is None else json.dumps(data).encode()
        headers={'Content-Type':'application/json','Cookie':'pg_session='+self.cookie, 'X-PG-CSRF':self.session['csrf']}
        request=urllib.request.Request(url,data=raw,headers=headers)
        try:
            with urllib.request.urlopen(request,timeout=4) as resp:return resp.status,json.load(resp)
        except urllib.error.HTTPError as err:return err.code,json.load(err)
    def test_new_code_claims_once_and_recovers_with_new_qr(self):
        status,reply=self.req(self.local,'/api/pair/new',{})
        self.assertEqual(status,200)
        code=reply['pairing'].split('|')[-1]
        status,wrong=self.req(self.lan,'/api/pair/claim',{'code':'not-the-code','name':'test phone'})
        self.assertEqual((status,wrong['error']),(409,'qr_code_mismatch'))
        status,paired=self.req(self.lan,'/api/pair/claim',{'code':code,'name':'test phone'})
        self.assertEqual(status,200)
        self.assertEqual(self.store.auth_device(paired['token']),paired['id'])
        status,used=self.req(self.lan,'/api/pair/claim',{'code':code,'name':'test phone'})
        self.assertEqual((status,used['error']),(410,'qr_expired_or_used'))
        status,reply2=self.req(self.local,'/api/pair/new',{})
        self.assertNotEqual(reply['pairing'],reply2['pairing'])
        status,paired2=self.req(self.lan,'/api/pair/claim',{'code':reply2['pairing'].split('|')[-1],'name':'phone 2'})
        self.assertEqual(status,200)
        self.assertNotEqual(paired['id'],paired2['id'])
    def test_expiration_and_status(self):
        status,reply=self.req(self.local,'/api/pair/new',{})
        code=reply['pairing'].split('|')[-1]
        with QR_LOCK:QR_STATE['until']=time.monotonic()-1
        status,expired=self.req(self.lan,'/api/pair/claim',{'code':code,'name':'phone'})
        self.assertEqual((status,expired['error']),(410,'qr_expired_or_used'))
        status,view=self.req(self.local,'/api/pair/status')
        self.assertEqual(view['remaining_seconds'],0)
        self.assertIn('หมดอายุ',view['last_pairing_result'])

if __name__=='__main__':unittest.main()
