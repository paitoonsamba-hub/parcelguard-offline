import sys,unittest,tempfile,threading,json,urllib.request,urllib.error
from pathlib import Path
from unittest.mock import patch
from http.server import ThreadingHTTPServer
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from server import Store,make_handler,SESSIONS,AUTH_LOCK,new_session,verify_pro_login
class TestLogin(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();self.store=Store(self.tmp.name)
  self.s=ThreadingHTTPServer(('127.0.0.1',0),make_handler(self.store,'local'));self.s.lan_enabled=True
  self.th=threading.Thread(target=self.s.serve_forever,daemon=True);self.th.start()
 def tearDown(self):
  self.s.shutdown();self.s.server_close();self.th.join(timeout=3);self.store.close();self.tmp.cleanup()
  with AUTH_LOCK:SESSIONS.clear()
 def req(self,path,data=None,headers=None):
  request=urllib.request.Request('http://127.0.0.1:'+str(self.s.server_port)+path,
     data=json.dumps(data).encode() if data is not None else None,headers=headers or {})
  try:
   with urllib.request.urlopen(request,timeout=3) as resp:return resp.status,resp.read(),resp.headers
  except urllib.error.HTTPError as exc:return exc.code,exc.read(),exc.headers
 def test_requires_login_and_csrf(self):
  code,_,_=self.req('/api/summary');self.assertEqual(code,401)
  cookie,session=new_session('owner@example.com')
  h={'Cookie':'pg_session='+cookie,'Content-Type':'application/json'}
  code,_,_=self.req('/api/pair/new',{},h);self.assertEqual(code,403)
  h['X-PG-CSRF']=session['csrf'];code,body,_=self.req('/api/pair/new',{},h)
  self.assertEqual(code,200);self.assertIn('pairing',json.loads(body))
 def test_server_validates_pro_not_just_auth(self):
  with patch('server.firebase_post') as mock:
   mock.side_effect=[{'idToken':'fake','email':'x@test.com'},{'result':{'active':True,'lifetime':True,'plan':'android','features':['android']}}]
   with self.assertRaises(ValueError):verify_pro_login('x@test.com','not-a-real-password')
   mock.side_effect=[{'idToken':'fake','email':'x@test.com'},{'result':{'active':True,'lifetime':True,'plan':'pro','features':['windows']}}]
   self.assertEqual(verify_pro_login('x@test.com','not-a-real-password'),'x@test.com')
if __name__=='__main__':unittest.main()
