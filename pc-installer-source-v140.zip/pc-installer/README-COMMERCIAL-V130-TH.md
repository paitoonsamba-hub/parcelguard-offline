# ParcelGuard Commercial Security V1.3.0 — PILOT ONLY

**ไม่ใช่ตัวขายจริงจนกว่าจะ Deploy Cloud Function และทดสอบหน้างาน**

## ความสามารถที่เพิ่ม
- PC Login ต้องผ่าน Firebase Email/Password และ Callable `commercialCheckPc` ซึ่งตรวจสิทธิ์ Pro ฿990, redeemed key ที่ไม่ถูกเพิกถอน และสถานะพักสิทธิ์
- จำกัด 1 PC ต่อ Firebase UID ผ่าน `commercialPcSeats/{uid}` บน Firestore (Atomic Transaction)
- หมายเลขเครื่องสุ่มเก็บเฉพาะที่ `%LOCALAPPDATA%\ParcelGuardPC\commercial-device-id` ไม่ผูก serial hardware; คัดลอกไฟล์นี้ไปเครื่องอื่นยังมีความเสี่ยง จึง **ยังไม่ใช่การป้องกันโคลนสมบูรณ์**
- Session ใน RAM, token refresh ใน RAM เท่านั้น, ตรวจสิทธิ์ซ้ำทุก 15 นาที โดยบล็อกการใช้งานเมื่อเซิร์ฟเวอร์เข้าถึงไม่ได้ (Fail Closed)
- ผู้ดูแล Owner สามารถย้ายเครื่องจาก callable `adminReleasePcSeat` พร้อมเหตุผลและ Audit Log
- ข้อมูล SQLite, ภาพ, วิดีโอ, QR, สแกน USB, พิมพ์ A4 ยังอยู่ในโครงสร้างเดิม

## ข้อจำกัดและก่อนขาย
1. **ห้ามใช้กับข้อมูลจริงก่อน** backup `%LOCALAPPDATA%\ParcelGuardPC` (Stable) โดยไฟล์ BAT ของ Pilot จะใช้ `%LOCALAPPDATA%\ParcelGuardPC-Pilot-V130` แยกจาก Stable อัตโนมัติ
2. ฟังก์ชัน Firebase `commercialCheckPc` และ `adminReleasePcSeat` ยัง **ไม่ได้ Deploy** อัตโนมัติ; เมื่อยังไม่ deploy การ Login รุ่น Pilot นี้จะไม่สำเร็จ (ออกแบบให้ fail closed)
3. รูปแบบ Trial 7 วันและ Mobile ฿490 บน Android ยังไม่ถูกแก้ในชุดนี้; PC ต้อง Pro เท่านั้น
4. ต้องทดสอบการถอนสิทธิ์, reset อุปกรณ์, ขาดอินเทอร์เน็ต, และเปลี่ยนเครื่อง PC จริง
5. LAN port 8766 ยังเป็น HTTP บน Wi-Fi ส่วนตัวเท่านั้น ไม่ควรเปิดให้บริการสาธารณะ; ต้องเพิ่ม TLS หรือ channel encryption ก่อนเปิดขายวงกว้าง
6. ห้ามแจก Password / Firebase ID token / refresh token ใน Screenshot หรือ Log
7. การบล็อกสิทธิ์เมื่อเน็ตขัดข้องเป็นข้อจำกัดของ Pilot; รุ่นใช้งานจริงควรกำหนด offline grace ที่ปลอดภัยและชัดเจน
8. ห้ามแก้ V1.2.9 Stable ทับ และห้ามย้ายฐานข้อมูลผู้ใช้โดยไม่สำรอง

## ฟังก์ชันใน GitHub
`feature/commercial-security-v1.3.0` (Firestore Rules ยังปิดทุก collection ต่อ client)

การ deploy (เฉพาะเมื่ออนุมัติหลังตรวจ tests):
```
firebase deploy --only functions:commercialCheckPc,functions:adminReleasePcSeat --project parcelguard-license
```

**หมายเหตุ**: การเพิกถอน License Key ที่ redeem แล้วใน Admin Dashboard เดิมยังไม่รองรับ หน้านั้นยกเลิกได้เฉพาะคีย์ที่ยังไม่ Redeem; ตรวจสอบและเพิ่มขั้นตอนที่ปลอดภัยก่อนขายจริง
