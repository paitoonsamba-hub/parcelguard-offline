ParcelGuard PC Station V1.2.1 - Login input usability fix

- Email is a normal editable text field (no browser email input restrictions); format checked on submit.
- Added explicit focus control and keyboard input state feedback.
- Password and Firebase Pro check, SQLite, QR and Wi-Fi receiver logic are unchanged.

Use: stop old START-PARCELGUARD-PC.bat, extract to a new directory, run batch file, open http://127.0.0.1:8765 and Ctrl+F5.
Data remains under %%LOCALAPPDATA%%\ParcelGuardPC. Never uninstall or delete existing data.
