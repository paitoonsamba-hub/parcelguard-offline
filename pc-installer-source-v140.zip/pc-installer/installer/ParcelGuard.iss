#define AppName "ParcelGuard PC Commercial"
#define AppVersion "1.4.0"
[Setup]
AppId={{73B56D54-D486-494D-8C97-139DCA8FF149}
AppName={#AppName}
AppVersion={#AppVersion}
AppPublisher=ParcelGuard
DefaultDirName={localappdata}\Programs\ParcelGuard PC Commercial
DefaultGroupName=ParcelGuard PC Commercial
PrivilegesRequired=lowest
OutputDir=..\output
OutputBaseFilename=ParcelGuard-PC-Setup-V1.4.0-PILOT
Compression=lzma2
SolidCompression=yes
WizardStyle=modern
DisableProgramGroupPage=yes
UninstallDisplayName=ParcelGuard PC Commercial
CloseApplications=no
RestartApplications=no
UsePreviousAppDir=yes
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible

[Files]
Source: "..\dist\ParcelGuardPC\*"; DestDir: "{app}"; Flags: ignoreversion recursesubdirs createallsubdirs
Source: "preinstall-backup.ps1"; Flags: dontcopy

[Icons]
Name: "{autoprograms}\ParcelGuard PC Commercial"; Filename: "{app}\ParcelGuardPC.exe"
Name: "{autodesktop}\ParcelGuard PC Commercial"; Filename: "{app}\ParcelGuardPC.exe"; Tasks: desktopicon

[Tasks]
Name: "desktopicon"; Description: "Create a desktop shortcut"

[Run]
Filename: "{app}\ParcelGuardPC.exe"; Description: "Run ParcelGuard PC"; Flags: nowait postinstall skipifsilent

[Code]
function PrepareToInstall(var NeedsRestart: Boolean): String;
var
  Code: Integer;
  ScriptPath: String;
begin
  Result := '';
  ExtractTemporaryFile('preinstall-backup.ps1');
  ScriptPath := ExpandConstant('{tmp}\preinstall-backup.ps1');
  if not Exec(ExpandConstant('{sys}\WindowsPowerShell\v1.0\powershell.exe'),
    '-NoProfile -NonInteractive -ExecutionPolicy Bypass -File "' + ScriptPath + '"',
    '', SW_HIDE, ewWaitUntilTerminated, Code) then
  begin
    Result := 'Cannot start the ParcelGuard backup check. Installation stopped; original data remains untouched.';
    Exit;
  end;
  if Code <> 0 then
    Result := 'Backup or port preflight failed (exit code ' + IntToStr(Code) + '). Close ParcelGuard and verify available disk space. Installation stopped without deleting data.';
end;
