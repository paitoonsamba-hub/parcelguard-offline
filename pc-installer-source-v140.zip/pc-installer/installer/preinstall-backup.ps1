# ParcelGuard installer: offline, read-only before copying user data to a new backup folder.
# Must exit nonzero if app is running or backup is incomplete. Never deletes original.
$ErrorActionPreference = 'Stop'
$data = Join-Path $env:LOCALAPPDATA 'ParcelGuardPC-Pilot-V130'
$backupRoot = Join-Path $env:LOCALAPPDATA 'ParcelGuardPC-Backups'
try {
  foreach ($port in @(8765,8766)) {
    $client = New-Object System.Net.Sockets.TcpClient
    try {
      $async = $client.BeginConnect('127.0.0.1', $port, $null, $null)
      if ($async.AsyncWaitHandle.WaitOne(250)) {
        try { $client.EndConnect($async); throw "ParcelGuard / other program still uses TCP port $port. Close the program before update." }
        catch [System.Net.Sockets.SocketException] { }
      }
    } finally { $client.Close() }
  }
  if (!(Test-Path -LiteralPath $data -PathType Container)) { exit 0 }
  New-Item -ItemType Directory -Force -Path $backupRoot | Out-Null
  $stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
  $target = Join-Path $backupRoot ("pre-v140-" + $stamp + "-" + $PID)
  New-Item -ItemType Directory -Force -Path $target | Out-Null
  # SQL db, -wal, -shm, device identity, photos/videos are copied together after the server stops.
  Get-ChildItem -LiteralPath $data -Force | ForEach-Object { Copy-Item -LiteralPath $_.FullName -Destination $target -Recurse -Force -ErrorAction Stop }
  # Validate each file exists and byte lengths match (including image evidence files).
  $sourceFiles = @(Get-ChildItem -LiteralPath $data -File -Recurse -Force)
  foreach ($source in $sourceFiles) {
    $rel = $source.FullName.Substring($data.Length).TrimStart('\')
    $copy = Join-Path $target $rel
    if (!(Test-Path -LiteralPath $copy -PathType Leaf)) { throw "Backup missing file: $rel" }
    if ((Get-Item -LiteralPath $copy).Length -ne $source.Length) { throw "Backup size mismatch: $rel" }
  }
  $note = "Source: $data`r`nCreated: $(Get-Date -Format o)`r`nVersion: pre-v1.4.0`r`n"
  Set-Content -LiteralPath (Join-Path $target 'BACKUP-INFO.txt') -Value $note -Encoding UTF8
  exit 0
} catch {
  [Console]::Error.WriteLine("ParcelGuard backup failed: " + $_.Exception.Message)
  exit 7
}
