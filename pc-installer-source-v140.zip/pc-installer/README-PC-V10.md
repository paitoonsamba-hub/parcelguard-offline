# ParcelGuard PC Station V1.0 — source-code pilot

This pilot extends the user's original PC HybridSync V0.3, retaining SQLite dashboard, tracking/bag search, image/video viewing and Android ZIP import.

## New: PC can scan parcels itself
1. Install Python 3.10+ on Windows.
2. Double-click `START-PARCELGUARD-PC.bat`. Dashboard opens at `http://127.0.0.1:8765`.
3. Select **สแกนพัสดุ PC** menu.
4. Attach a USB scanner in **keyboard HID / keyboard wedge** mode, configured to send Enter after scanning. Focus the Tracking field.
5. Click **เปิดกล้องเว็บแคม**, allow camera access, choose carrier and bag. Scanner + Enter captures a JPEG and commits to SQLite.
6. Open **ภาพรวม** or **ค้นหลักฐาน** to view the record and image. Duplicates are rejected rather than overwritten.
7. Every PC scan includes a camera JPEG; the browser camera works only via localhost. It records a 3-second WebM clip when MediaRecorder is supported, then captures JPEG; imported Android MP4 also plays in evidence viewer.

## Android evidence intake
- **Manual import (works now):** Android Settings → export ZIP, copy to Windows, PC → ซิงก์และอุปกรณ์ → นำเข้า ZIP. Supports multi-parcel ZIP, JPEG and MP4, reuses existing SQLite import.
- **LAN input endpoint (implemented):** `START-PARCELGUARD-PC.bat` enables TCP 8766 on trusted private Wi-Fi. Local UI can create token through ซิงก์และอุปกรณ์ → เพิ่มอุปกรณ์. Android → ตั้งค่า Hybrid Sync → PC IP + Token. Phone must have compatible APK; app must be open during syncing.
- **QR claim API (implemented):** POST `/api/pair/claim` with JSON `{code,name}`. Local POST `/api/pair/new` returns `PGPAIR1|ip|8766|code`, which can be rendered as QR by a compatible client. The dashboard now displays the actual 90-second pairing QR through the local server. Run the launcher to install its qrcode/Pillow dependency. Android pairing must still be tested against a matching APK.
- Android sends a **single parcel ZIP** (including `manifest.csv`, JPG, optional MP4) to `/api/sync/archive`. Server responds `{status:"imported"}` or `{status:"already_imported"}` for existing Android client.
- Data lives in `%LOCALAPPDATA%\ParcelGuardPC` (SQLite + media); back up this entire folder before updating.

## Important pilot limits
- This base program has **no Firebase Pro entitlement gate yet**; **do not sell or distribute to customers as the paid Pro edition**. Merge license checks with PC server before release.
- HTTP LAN is not encrypted. Use only trusted private shop Wi-Fi, never public/guest Wi-Fi or forwarded port.
- Supports USB HID barcode scanners, not special USB serial protocol scanners. PC webcam capture works when explicitly opened.
- PC scanner records 3-second WebM when supported, then JPEG; Android imported videos remain MP4. For Android, ZIP import preserves JPG and MP4 when present.
- Upload and LAN are functional implementation paths but Android-to-PC end-to-end compatibility is not proven until tested on actual paired devices.
- No PC standalone EXE in this pilot; requires Python.


## V1.1 QR hotfix (2026-11-13)
- QR 403 เดิมตรวจไม่ออกว่าหมดอายุหรือรหัสผิด: ใหม่ตอบ HTTP 410 เมื่อหมดอายุ/ใช้แล้ว, HTTP 409 เมื่อรหัสไม่ตรง และแสดงสถานะในเมนูซิงก์และอุปกรณ์
- เปิดทั้งพอร์ต 8765 และ 8766 สำเร็จก่อนเริ่ม Dashboard ไม่เช่นนั้นแจ้งโปรแกรมเก่าครองพอร์ตและไม่เปิดเว็บหลอกว่าเชื่อมต่อได้
- สร้าง QR ใหม่ 90 วินาทีจากหน้า PC แล้วสแกน/ยืนยันจับคู่ทันที (การจับคู่สำเร็จไม่ใช่การรับพัสดุสำเร็จ)
- เปิด Command Prompt ที่รันโปรแกรมค้างไว้เพื่อดู `[PAIR]` และ `[SYNC]` ขณะทดสอบ
- หาก HTTP 409 ทันทีทั้งที่เพิ่งสร้าง QR ให้ปิดโปรแกรม ParcelGuard PC/Receiver เก่าทั้งหมดแล้วรัน START-PARCELGUARD-PC.bat ใหม่ อย่าใช้ URL ของเซิร์ฟเวอร์ที่เปิดค้าง
- ไม่มีการเปลี่ยนชื่อฐานข้อมูล SQLite หรือโฟลเดอร์หลักฐานเดิม และไม่มีการแก้ Firebase

## V1.2 — Firebase Pro Login + Android PC Status

- เปิด `http://127.0.0.1:8765` จะพบหน้า Login (Email / Password)
- ใช้บัญชี Firebase ที่ Redeem Pro Lifetime ฿990 แล้วเท่านั้น; ตรวจสิทธิ์ผ่าน `checkAccess` บน Firebase
- Login ครั้งนี้มีอายุสูงสุด 8 ชั่วโมงขณะเปิดเซิร์ฟเวอร์; ออกระบบได้จากปุ่มด้านขวาล่าง
- ข้อมูล SQLite และไฟล์รูป/วิดีโอเดิมจะไม่ถูกลบหรือย้าย
- LAN API ตอบรับจับคู่และรับ ZIP เฉพาะเมื่อมีผู้ดูแล PC ที่ Login อยู่
- `GET /api/device/status` บน LAN พอร์ต 8766 รับเฉพาะ Bearer Token มือถือที่จับคู่แล้ว และส่งชื่อคอม, IP และสถานะพร้อมรับกลับไป
- Android Companion รุ่น V0.8.6 แสดงชื่อ PC / IP / สถานะออนไลน์ และเวลาซิงก์ล่าสุดในหน้า Settings
- สถานะที่แสดงบนมือถือเป็นผลจากการสอบถาม PC จริง ไม่ได้ดูจาก QR อย่างเดียว
- ต้องมีอินเทอร์เน็ตเมื่อเข้าสู่ระบบ PC และต้องใช้ Wi-Fi ส่วนตัวที่เชื่อถือได้สำหรับการรับไฟล์
- การตรวจสิทธิ์ครั้งนี้ทำตอน Login และ Session หมดอายุ ไม่ใช่การตรวจซ้ำทุก 5 นาที ควรปรับก่อนจำหน่ายจริง
- PC เป็นโปรแกรม Python รุ่นทดลอง ยังไม่ใช่ไฟล์ EXE ที่เซ็น Code Signing
