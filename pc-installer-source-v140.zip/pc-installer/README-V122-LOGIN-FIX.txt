ParcelGuard PC Station V1.2.2 — Login submit hotfix

Root cause: CSP script-src self blocks inline JavaScript in web/login.html.
Remediation: move login JS to web/login.js, allow this asset for logged-out users.
Also align Firebase public Web API key with registered ParcelGuard-Licence project config.
No database schema or QR/ZIP sync changes.

How to install:
1. Close old START-PARCELGUARD-PC and its terminal.
2. Extract this ZIP to a NEW folder.
3. Run START-PARCELGUARD-PC.bat, open http://127.0.0.1:8765 and Ctrl+F5.
4. Fill email/password and submit. Status shows Firebase errors or redirects to Dashboard.
5. Back up any current PC data in %LOCALAPPDATA%\ParcelGuardPC before troubleshooting, never delete originals.
