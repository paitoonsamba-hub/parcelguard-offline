@echo off
setlocal
cd /d "%~dp0"
echo ==============================================
echo EXPERIMENTAL LAN HTTP - NOT ENCRYPTED
 echo Use only on your trusted private Wi-Fi network.
echo Never forward port 8766 to the Internet.
echo Android V0.4.3 LAN pilot can auto-sync when opened and paired.
echo ==============================================
where py >nul 2>&1
if %errorlevel%==0 (py -3 server.py --lan) else (python server.py --lan)
if errorlevel 1 pause
