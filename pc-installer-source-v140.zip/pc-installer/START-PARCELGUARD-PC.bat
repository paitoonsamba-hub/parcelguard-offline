@echo off
setlocal
cd /d "%~dp0"
if exist "ParcelGuardPC.exe" (
  start "" "ParcelGuardPC.exe"
  exit /b 0
)
if exist "dist\ParcelGuardPC\ParcelGuardPC.exe" (
  start "" "dist\ParcelGuardPC\ParcelGuardPC.exe"
  exit /b 0
)
echo Installer pilot: Windows EXE has not been built yet.
echo Build with BUILD-WINDOWS.bat on a trusted Windows build machine, or use GitHub Actions.
echo No fallback to downloading Python automatically.
pause
exit /b 1
