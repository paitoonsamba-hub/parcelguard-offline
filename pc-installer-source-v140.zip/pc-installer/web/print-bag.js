"use strict";
const el=id=>document.getElementById(id);
const put=(id,value)=>{el(id).textContent=String(value)};
const fmt=(ms)=>{
  if(!ms)return '—';
  const n=Number(ms);
  if(!Number.isFinite(n))return '—';
  return new Date(n).toLocaleString('th-TH',{dateStyle:'short',timeStyle:'short',hour12:false});
};
async function loadJson(path){
 const response=await fetch(path,{cache:'no-store'});
 if(!response.ok)throw Error('โหลดข้อมูลจาก PC ไม่สำเร็จ (HTTP '+response.status+')');
 return response.json();
}
async function main(){
 try{
   const auth=await loadJson('/api/auth/status');
   if(auth.authenticated!==true){location.replace('/login.html');return}
   const key=new URLSearchParams(location.search).get('bag');
   if(!key)throw Error('ไม่ได้เลือกรหัสถุง');
   const bags=await loadJson('/api/bags');
   if(!Array.isArray(bags))throw Error('รูปแบบข้อมูลถุงไม่ถูกต้อง');
   const bag=bags.find(b=>b.key===key);
   if(!bag)throw Error('ไม่พบถุงนี้ในฐานข้อมูล PC');
   const scanned=Array.isArray(bag.scanned)?bag.scanned:[];
   const expected=Array.isArray(bag.expected)?bag.expected:[];
   const missing=Array.isArray(bag.missing)?bag.missing:[];
   const extra=Array.isArray(bag.extra)?bag.extra:[];
   const hasList=Boolean(bag.manifest_loaded);
   put('bag-id',bag.bag_id||'—');put('carrier',bag.carrier||'—');
   put('bag-status',bag.closed?'ปิดถุงแล้ว':'ยังไม่ปิดถุง');
   put('count-scanned',scanned.length);
   put('count-expected',hasList?expected.length:'—');
   put('count-difference',hasList?missing.length+' / '+extra.length:'—');
   put('bag-result',bag.verified?'ตรงรายการ':(hasList?'ต้องตรวจ':'ยังไม่เทียบ'));
   put('device-name',bag.device_name||'—');
   put('printed-at',new Date().toLocaleString('th-TH',{dateStyle:'medium',timeStyle:'short',hour12:false}));
   put('items-count','รวม '+scanned.length+' ชิ้น');put('grand-total',scanned.length);
   const tbody=el('items');
   const fragment=document.createDocumentFragment();
   // Three vertical columns, with one unique Tracking per numbered position.
   // Example: 60 parcels => left 1-20, middle 21-40, right 41-60.
   // Use only bag.scanned from the existing authenticated database API.
   document.documentElement.classList.toggle('print-spacious-60',scanned.length >= 54 && scanned.length <= 66);
   document.documentElement.classList.toggle('print-compact',scanned.length >= 45 && scanned.length <= 75 && !(scanned.length >= 54 && scanned.length <= 66));
   const rows=Math.ceil(scanned.length/3);
   for(let rowIndex=0;rowIndex<rows;rowIndex++){
     const tr=document.createElement('tr');
     for(let column=0;column<3;column++){
       const index=column*rows+rowIndex;
       const cell=document.createElement('td');
       if(index<scanned.length){
         const code=document.createElement('span');
         code.className='tracking-code';
         code.textContent=String(scanned[index]);
         const serial=document.createElement('span');
         serial.className='tracking-number';
         serial.textContent=String(index+1)+'.';
         cell.append(serial,code);
       }else{
         cell.className='empty-tracking-cell';
       }
       tr.appendChild(cell);
     }
     fragment.appendChild(tr);
   }
   if(!scanned.length){
     const tr=document.createElement('tr');
     const cell=document.createElement('td');
     cell.colSpan=3;
     cell.textContent='ยังไม่มีรายการ Tracking ในถุงนี้';
     tr.appendChild(cell);fragment.appendChild(tr);
   }
   tbody.replaceChildren(fragment);
   const message=[];
   if(!bag.closed)message.push('ถุงนี้ยังไม่ได้ยืนยันการปิดถุง');
   if(hasList&&!bag.verified)message.push('รายการไม่ตรงกับยอดคาดหมาย: ขาด '+missing.length+' ชิ้น / เกิน '+extra.length+' ชิ้น');
   if(!hasList)message.push('ยังไม่มีรายการคาดหมายสำหรับเทียบยอด');
   if(!message.length){el('notice').classList.add('ok');message.push('ตรวจนับรายการแล้วตรงตามข้อมูลที่โหลดไว้ กรุณาตรวจพัสดุจริงก่อนเซ็นรับมอบ')}
   put('notice',message.join(' • '));
   put('message','พร้อมพิมพ์ • '+(bag.bag_id||'')+' • '+scanned.length+' ชิ้น');
   el('do-print').disabled=false;
 }catch(error){put('message','เปิดใบพิมพ์ไม่ได้: '+error.message);el('message').classList.add('error')}
}
el('do-print').addEventListener('click',()=>window.print());
el('close-print').addEventListener('click',()=>window.close());
main();
