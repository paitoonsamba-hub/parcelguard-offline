(function(){
'use strict';
const email=document.getElementById('email');
const password=document.getElementById('password');
const status=document.getElementById('status');
const send=document.getElementById('send');
document.getElementById('login').addEventListener('submit',async(event)=>{
 event.preventDefault();
 const address=email.value.trim();
 if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(address)){
   status.textContent='กรุณากรอกอีเมลให้ถูกต้อง เช่น example@gmail.com';email.focus();return;
 }
 if(!password.value){status.textContent='กรุณากรอกรหัสผ่าน';password.focus();return;}
 send.disabled=true;
 status.textContent='กำลังตรวจสอบ License Pro กับ Firebase...';
 try{
   const response=await fetch('/api/auth/login',{
     method:'POST',credentials:'same-origin',headers:{'Content-Type':'application/json'},
     body:JSON.stringify({email:address,password:password.value})
   });
   const contentType=response.headers.get('content-type')||'';
   if(!contentType.includes('application/json'))throw Error('เซิร์ฟเวอร์ตอบข้อมูลไม่ถูกต้อง • ตรวจว่าเปิดโปรแกรมรุ่นใหม่แล้ว');
   const data=await response.json();
   if(!response.ok)throw Error(data.error||'เข้าสู่ระบบไม่สำเร็จ');
   password.value='';status.textContent='เข้าสู่ระบบสำเร็จ • กำลังเปิด Dashboard...';window.location.replace('/');
 }catch(error){status.textContent=error.message||'เข้าสู่ระบบไม่ได้ โปรดลองอีกครั้ง';}
 finally{send.disabled=false;}
});
})();
