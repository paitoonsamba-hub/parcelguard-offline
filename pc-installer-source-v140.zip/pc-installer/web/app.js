/* ParcelGuard PC — real local dashboard for imported Android evidence ZIP files.
   The LAN client on Android and Cloud remain separate future work. */
'use strict';
const $ = id => document.getElementById(id);
const esc = x => String(x ?? '').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const pill = (text,type) => `<span class="pill pill-${type}">${esc(text)}</span>`;
let bags=[], devices=[], parcels=[], selectedBag='', currentPage='overview', config=null;
const fmt = n => n ? new Date(n).toLocaleString('th-TH',{hour12:false}) : '—';
const csvEscape = v=>{let s=String(v??'');if(/^[=+\-@\t\r]/.test(s))s="'"+s;return '"'+s.replaceAll('"','""')+'"'};
async function api(url,opts={}) {if(opts.method&&opts.method!=='GET'){opts.headers={...(opts.headers||{}),'X-PG-CSRF':window.PG_CSRF||''}}let res=await fetch(url,{cache:'no-store',...opts});if(res.status===401){location.href='/login.html';throw Error('เข้าสู่ระบบ Pro ก่อน')} let ctype=res.headers.get('content-type')||'';let data=ctype.includes('json')?await res.json():await res.text();if(!res.ok)throw Error(data.error||'ผิดพลาด HTTP '+res.status);return data;}
function toast(msg){const el=$('toast');el.textContent=msg;el.classList.add('show');clearTimeout(window._toastTimer);window._toastTimer=setTimeout(()=>el.classList.remove('show'),4300)}
function downloadFile(name,contents,mime='text/csv;charset=utf-8'){const u=URL.createObjectURL(new Blob([contents],{type:mime}));let a=document.createElement('a');a.href=u;a.download=name;document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(u),2000)}
async function refresh() {try{const s=await api('/api/summary');bags=s.bags;devices=s.devices;parcels=await api('/api/parcels');$('top-date').textContent=new Date().toLocaleDateString('th-TH');$('connection-label').textContent='PC LOCAL • ข้อมูลจริง';renderAll();}catch(e){toast('เชื่อมต่อฐานข้อมูลไม่สำเร็จ: '+e.message)}}
function getBag(key){return bags.find(x=>x.key===key)}
function navigate(name){if(!['scanner','overview','bags','evidence','manifest','devices','settings'].includes(name))return;currentPage=name;document.querySelectorAll('.page').forEach(e=>e.classList.toggle('active',e.id===`page-${name}`));document.querySelectorAll('.nav-link').forEach(e=>e.classList.toggle('active',e.dataset.page===name));const names={scanner:'สแกนพัสดุ PC',overview:'ภาพรวม',bags:'ตรวจถุงพัสดุ',evidence:'ค้นหลักฐาน',manifest:'รายการ Tracking',devices:'ซิงก์และอุปกรณ์',settings:'ตั้งค่าระบบ'};$('breadcrumb-current').textContent=names[name];$('sidebar').classList.remove('open');renderAll();window.scrollTo(0,0)}
function audit(b){return {missing:b.missing||[],extra:b.extra||[],verified:!!b.verified,loaded:!!b.manifest_loaded}}
function evidenceRecords(){return parcels.map(r=>({...r,bag:r.bag_id,time:fmt(r.scanned_at),video:!!r.video_sha,photo:!!r.photo_sha}));}
function renderAll(){renderOverview();renderBags();renderEvidence();renderManifest();renderDevices()}
function renderOverview(){const scanned=bags.reduce((s,b)=>s+b.scanned.length,0),review=bags.filter(b=>!b.verified).length,closed=bags.filter(b=>b.closed).length,verified=bags.length-review;
 const metrics=[{label:'สแกนทั้งหมด',n:scanned,sub:'ข้อมูลที่รับเข้า PC จริง',icon:'▥',color:'#ff9917',tint:'#49331e'},{label:'ถุงพัสดุ',n:bags.length,sub:`ปิดแล้ว ${closed} ถุง`,icon:'▣',color:'#57abfa',tint:'#18354d'},{label:'ถุงยังไม่ยืนยัน',n:review,sub:'ไม่มีรายการ / ขาด / เกิน',icon:'⚑',color:'#ff757e',tint:'#46272f'},{label:'อุปกรณ์ที่ลงทะเบียน',n:devices.filter(x=>x.id!=='pc').length,sub:'LAN ต้องมี Android Sync เพิ่ม',icon:'⇄',color:'#20d7a1',tint:'#173c34'}];
 $('metrics').innerHTML=metrics.map(x=>`<div class="metric" style="--stripe:${x.color};--tint:${x.tint}"><div class="metric-top"><span>${x.label}</span><span class="metric-icon">${x.icon}</span></div><div class="metric-number">${x.n.toLocaleString('en-US')}</div><div class="metric-bottom">${esc(x.sub)}</div></div>`).join('');
 const days=[...Array(7)].map((_,i)=>{let d=new Date();d.setHours(0,0,0,0);d.setDate(d.getDate()-6+i);const t=d.getTime();return {label:new Intl.DateTimeFormat('th-TH',{weekday:'short'}).format(d),count:parcels.filter(r=>r.scanned_at>=t&&r.scanned_at<t+86400000).length}});let max=Math.max(...days.map(x=>x.count),1);
 $('weekly-chart').innerHTML=days.map(x=>`<div class="bar-group"><div class="bar-col" style="height:${Math.max(3,Math.round(x.count/max*85))}%" title="${x.count} ชิ้น"><span class="bar-val">${x.count||''}</span></div><span class="bar-day">${x.label}</span></div>`).join('');
 const percent=bags.length?Math.round(verified/bags.length*100):0;let missingBags=bags.filter(b=>b.missing.length).length,extraBags=bags.filter(b=>b.extra.length).length; $('donut').style.background=`conic-gradient(var(--green) 0% ${percent}%,var(--orange) ${percent}% 100%)`;$('donut-num').textContent=percent+'%';$('ring-legend').innerHTML=[[verified,'ตรวจผ่าน','var(--green)'],[missingBags,'มีเลขขาด','var(--orange)'],[extraBags,'มีเลขเกิน','var(--red)']].map(([n,l,c])=>`<div class="legend-row"><span class="legend-dot" style="background:${c}"></span>${l}<b>${n}</b></div>`).join('');
 $('nav-issues').textContent=String(review);$('attention-bags').innerHTML=bags.filter(b=>!b.verified).slice(0,6).map(b=>{let a=audit(b);return `<div class="attention-row" data-openbag="${esc(b.key)}"><div class="bag-mini-icon">▣</div><div class="bag-text"><b>${esc(b.bag_id)}</b><small>${esc(b.carrier)} · ${b.scanned.length}/${b.expected.length} เลข</small></div><div class="right">${pill(b.scanned.length+' รายการ','blue')}${a.missing.length?pill('ขาด '+a.missing.length,'amber'):''}${a.extra.length?pill('เกิน '+a.extra.length,'red'):''}<span>›</span></div></div>`}).join('')||'<p class="minor">ไม่มีถุงรอตรวจ</p>';
 const totals={};bags.forEach(b=>totals[b.carrier]=(totals[b.carrier]||0)+b.scanned.length);let palette={'SPX':'#ff9e24','Flash':'#6e9dff','J&T':'#ef6877','LEX':'#15c7a2'}; $('carrier-bars').innerHTML=Object.entries(totals).map(([name,n])=>`<div class="carrier-line"><div class="carrier-header"><b>${esc(name)}</b><span>${n} ชิ้น</span></div><div class="track"><span style="width:${scanned?Math.round(n/scanned*100):0}%;--bar:${palette[name]||'#aaa'}"></span></div></div>`).join('')||'<p class="minor">ยังไม่มีข้อมูล</p>';
 $('recent-table').innerHTML=evidenceRecords().slice(0,8).map(r=>`<tr><td class="tracking">${esc(r.tracking)}</td><td>${esc(r.bag)}</td><td>${esc(r.carrier)}</td><td>${pill(r.video?'รูป + วิดีโอ':r.photo?'รูปภาพ':'ไม่พบไฟล์','blue')}</td><td>${pill('เก็บใน PC','green')}</td><td>${esc(r.time)}</td><td><button class="table-button" data-evidence="${esc(r.device_id+'|'+r.tracking)}">ดู ›</button></td></tr>`).join('')||'<tr><td colspan="7" style="text-align:center;padding:35px">ยังไม่มีหลักฐาน — นำเข้า ZIP จาก Android ที่หน้าซิงก์และอุปกรณ์</td></tr>';
}
function renderBags(){const q=$('bag-search').value.toLowerCase(), f=$('bag-filter').value;let rows=bags.filter(b=>(b.bag_id.toLowerCase().includes(q)||b.carrier.toLowerCase().includes(q))&&(f==='all'||f==='review'&&!b.verified||f==='verified'&&b.verified||f==='open'&&!b.closed));$('bags-count').textContent=rows.length+' ถุง';$('bags-table').innerHTML=rows.map(b=>`<tr><td><span class="tracking">${esc(b.bag_id)}</span><div class="minor">${b.closed?'ปิดแล้ว':'เปิดหรือไม่ทราบสถานะ'} · ${esc(b.device_name)}</div></td><td>${esc(b.carrier)}</td><td>${b.expected.length||'—'}</td><td>${b.scanned.length}</td><td style="color:#ffb35a">${b.manifest_loaded?b.missing.length:'—'}</td><td style="color:#ff8f98">${b.manifest_loaded?b.extra.length:'—'}</td><td>${b.verified?pill('✓ ตรงรายการ','green'):pill(b.manifest_loaded?'⚑ ต้องตรวจ':'ยังไม่ได้รายการ','amber')}</td><td><button class="table-button" data-openbag="${esc(b.key)}">ดูรายการ ↗</button><button class="table-button" data-printbag="${esc(b.key)}" style="margin-left:8px">พิมพ์ A4</button></td></tr>`).join('')||'<tr><td colspan="8" style="text-align:center;padding:35px">ไม่พบถุง — นำเข้าหลักฐาน ZIP ก่อน</td></tr>'}
function renderEvidence(){let q=$('evidence-search').value.toLowerCase(),f=$('evidence-carrier').value;let rows=evidenceRecords().filter(r=>(r.tracking.toLowerCase().includes(q)||r.bag.toLowerCase().includes(q))&&(f==='all'||r.carrier===f));$('evidence-summary').textContent=`แสดง ${rows.length} รายการ — ข้อมูลจริงที่นำเข้าใน PC (ยังไม่ได้ซิงก์อัตโนมัติจาก Android)`;$('evidence-table').innerHTML=rows.map(r=>`<tr><td class="tracking">${esc(r.tracking)}</td><td>${esc(r.bag)}</td><td>${esc(r.time)}</td><td>${pill(r.video?'JPEG + MP4':r.photo?'JPEG':'ไม่มีไฟล์','blue')}</td><td>${pill('เก็บใน PC','green')}</td><td><button class="table-button" data-evidence="${esc(r.device_id+'|'+r.tracking)}">เปิดหลักฐาน ↗</button></td></tr>`).join('')||'<tr><td colspan="6" style="text-align:center;padding:35px">ไม่พบ Tracking ที่ค้นหา</td></tr>'}
function renderManifest(){const sel=$('manifest-bag'),old=sel.value||selectedBag;sel.innerHTML=bags.map(b=>`<option value="${esc(b.key)}">${esc(b.bag_id)} · ${esc(b.carrier)} (${esc(b.device_name)})</option>`).join('');if(!bags.length){sel.innerHTML='<option value="">ยังไม่มีถุง</option>';$('manifest-summary').innerHTML='<div class="minor">นำเข้าหลักฐาน ZIP ที่หน้าอุปกรณ์ หรือสร้างถุงทดสอบก่อน</div>';$('manifest-result').innerHTML='';return;}sel.value=bags.some(x=>x.key===old)?old:bags[0].key;selectedBag=sel.value;let b=getBag(selectedBag),a=audit(b);$('manifest-summary').innerHTML=`<div class="minor">ถุง <b style="color:white">${esc(b.bag_id)}</b></div><div class="audit-metrics"><div class="audit-metric"><b>${b.expected.length}</b><small>รายการที่ต้องส่ง</small></div><div class="audit-metric"><b style="color:#ffb14b">${a.loaded?a.missing.length:'—'}</b><small>เลขที่ขาด</small></div><div class="audit-metric"><b style="color:#ff8896">${a.loaded?a.extra.length:'—'}</b><small>เลขที่เกิน</small></div></div><div style="margin-top:13px">${b.verified?pill('✓ ตรวจผ่าน','green'):pill(a.loaded?'⚑ ยังไม่ตรง':'⚑ ยังไม่มีรายการ','amber')}</div>`;
 const section=(label,codes,color)=>`<div class="list-section"><h3 style="color:${color}">${label} (${codes.length})</h3>${codes.length?codes.slice(0,35).map(x=>`<div class="code-row">${esc(x)}</div>`).join(''):'<div class="minor">ไม่มี</div>'}</div>`;$('manifest-result').innerHTML=section('ยังขาด',a.missing,'#ffbd6e')+section('เลขเกิน',a.extra,'#ff8b95')}
function renderDevices(){const list=devices.filter(x=>x.id!=='pc');$('device-list').innerHTML=list.map(d=>`<div class="device-row"><div class="device-icon">▯</div><div><b>${esc(d.name)}</b><small>รหัสอุปกรณ์ ${esc(d.id)} · ${d.last_seen?'รับข้อมูลล่าสุด '+fmt(d.last_seen):'ยังไม่เคยส่งข้อมูล'}</small></div>${pill(d.last_seen?'รับ ZIP แล้ว':'รอเชื่อมต่อ',d.last_seen?'green':'amber')}</div>`).join('')||'<div class="minor">ยังไม่มีมือถือที่ลงทะเบียน — สามารถนำเข้าหลักฐาน ZIP ด้วยตนเองได้ทันที</div>'}
function openModal(title,html,overline='DETAIL'){$('modal-title').textContent=title;$('modal-overline').textContent=overline;$('modal-content').innerHTML=html;$('modal').classList.add('open');$('modal').setAttribute('aria-hidden','false')}
function closeModal(){$('modal').classList.remove('open');$('modal').setAttribute('aria-hidden','true')}
function openBag(key){
 const b=getBag(key);if(!b)return;
 const a=audit(b);
 const matched=b.scanned.filter(x=>b.expected.includes(x)).length;
 const makeList=codes=>codes.length?codes.slice(0,100).map(x=>`<div class="code-row">${esc(x)}</div>`).join(''):'<div class="minor">ไม่มี</div>';
 // b.scanned is the actual scanned Tracking list, distinct from the optional expected manifest.
 // Escape bag names and tracking values before inserting into HTML.
 const scans=b.scanned||[];
 const trackingRows=scans.map((tracking,i)=>`<li class="bag-tracking-item"><span class="bag-tracking-index">${i+1}.</span><span class="bag-tracking-code">${esc(tracking)}</span></li>`).join('');
 const printButton=`<button type="button" class="btn btn-primary bag-print-action" data-printbag="${esc(b.key)}">▤ พิมพ์ใบส่งมอบ A4</button>`;
 openModal(b.bag_id,`<div class="detail-grid"><div class="detail-cell"><span>รายการที่ต้องส่ง</span><b>${b.manifest_loaded?b.expected.length:'ยังไม่มีรายการ'}</b></div><div class="detail-cell"><span>สแกนแล้ว</span><b style="color:var(--green)">${scans.length}</b></div><div class="detail-cell"><span>ขาด / เกิน</span><b style="color:var(--orange)">${b.manifest_loaded?a.missing.length+' / '+a.extra.length:'—'}</b></div></div>
 <div style="margin:12px 0">${b.verified?pill('✓ ตรวจผ่าน','green'):pill('ต้องตรวจ','amber')} <span class="minor">${esc(b.device_name)}</span></div>
 <section class="bag-tracking-panel"><div class="bag-tracking-heading"><h3>รายการพัสดุในถุง</h3><span>${scans.length} รายการ</span></div>${scans.length?`<ol class="bag-tracking-list">${trackingRows}</ol>`:'<p class="minor">ยังไม่มีรายการพัสดุในถุงนี้</p>'}</section>
 <div class="modal-columns"><div class="list-section"><h3 style="color:#ffbd6e">เลขที่ขาด</h3>${makeList(a.missing)}</div><div class="list-section"><h3 style="color:#ff8b95">เลขเกิน</h3>${makeList(a.extra)}</div></div>
 <div class="bag-modal-actions">${printButton}<button type="button" class="btn btn-secondary" data-close-bag>ปิด</button></div>`,'BAG AUDIT');
}

function openEvidence(key){const r=parcels.find(x=>x.device_id+'|'+x.tracking===key);if(!r)return;let preview=r.photo_sha?`<img src="/api/media/${r.photo_sha}" alt="หลักฐานภาพพัสดุ" style="max-width:100%;max-height:350px;object-fit:contain;border-radius:12px">`:'<div class="minor">ไม่มีภาพ JPEG</div>';let video=r.video_sha?`<video controls preload="metadata" style="width:100%;max-height:280px;margin-top:14px;border-radius:12px" src="/api/media/${r.video_sha}"></video>`:'<div class="minor" style="margin-top:14px">ไม่มีวิดีโอรายชิ้น</div>';openModal(r.tracking,`<div style="text-align:center">${preview}</div>${video}<div class="detail-grid"><div class="detail-cell"><span>ถุง</span><b style="font-size:12px">${esc(r.bag_id)}</b></div><div class="detail-cell"><span>ขนส่ง</span><b>${esc(r.carrier)}</b></div><div class="detail-cell"><span>เวลาที่สแกน</span><b style="font-size:12px">${esc(fmt(r.scanned_at))}</b></div></div>`,'EVIDENCE')}
async function postBinary(endpoint,file){return api(endpoint,{method:'POST',headers:{'Content-Type':'application/octet-stream'},body:file})}
async function importZip(file){if(!file)return;if(!/\.zip$/i.test(file.name)){toast('เลือกไฟล์ .zip ที่ส่งออกจาก ParcelGuard Android');return;}toast('กำลังนำเข้าหลักฐาน กรุณารอจนเสร็จ');try{let out=await postBinary('/api/import-zip',file);toast(out.already_imported?'ไฟล์นี้นำเข้าแล้ว ไม่มีข้อมูลซ้ำ':`นำเข้า ${out.imported} พัสดุ และ ${out.files} ไฟล์หลักฐานแล้ว`);await refresh()}catch(e){toast('นำเข้า ZIP ไม่ผ่าน: '+e.message)}}
async function importExpected(file){if(!file)return;if(!/\.csv$/i.test(file.name))return toast('รองรับ CSV เท่านั้น');if(!selectedBag)return toast('ต้องมีถุงก่อน');try{let n=await postBinary('/api/import-expected?bag='+encodeURIComponent(selectedBag),file);toast('บันทึก '+n.count+' เลขในฐานข้อมูลจริงแล้ว');await refresh()}catch(e){toast('นำเข้า Tracking ไม่สำเร็จ: '+e.message)}}
function exportAudit(){let b=getBag(selectedBag);if(!b)return toast('เลือกถุงก่อน');let s=new Set(b.scanned),e=new Set(b.expected);let lines=['tracking,bag,status',...b.expected.map(x=>[csvEscape(x),csvEscape(b.bag_id),csvEscape(s.has(x)?'SCANNED':'MISSING')].join(',')),...b.scanned.filter(x=>!e.has(x)).map(x=>[csvEscape(x),csvEscape(b.bag_id),csvEscape('UNEXPECTED')].join(','))];downloadFile('ParcelGuard-Audit-'+b.bag_id+'.csv','\ufeff'+lines.join('\r\n'));toast('ส่งออกผลตรวจถุงแล้ว')}
function wire(){document.addEventListener('click',e=>{let nav=e.target.closest('[data-page]');if(nav){navigate(nav.dataset.page);return}let dismiss=e.target.closest('[data-close-bag]');if(dismiss){closeModal();return}let pb=e.target.closest('[data-printbag]');if(pb){window.open('/print-bag.html?bag='+encodeURIComponent(pb.dataset.printbag),'_blank','noopener');return}let b=e.target.closest('[data-openbag]');if(b){openBag(b.dataset.openbag);return}let v=e.target.closest('[data-evidence]');if(v){openEvidence(v.dataset.evidence);return}let a=e.target.closest('[data-action]');if(a&&a.dataset.action==='export-summary')window.location='/api/export/report.csv'});
 $('bag-filter').onchange=renderBags;$('bag-search').oninput=renderBags;$('evidence-search').oninput=renderEvidence;$('evidence-carrier').onchange=renderEvidence;$('clear-evidence').onclick=()=>{$('evidence-search').value='';$('evidence-carrier').value='all';renderEvidence()};$('manifest-bag').onchange=()=>{selectedBag=$('manifest-bag').value;renderManifest()};$('choose-csv').onclick=()=>$('csv-file').click();$('csv-file').onchange=e=>importExpected(e.target.files[0]);const zone=$('upload-zone');zone.ondragover=e=>{e.preventDefault();zone.classList.add('drag')};zone.ondragleave=()=>zone.classList.remove('drag');zone.ondrop=e=>{e.preventDefault();zone.classList.remove('drag');importExpected(e.dataTransfer.files[0])};
 $('print-bag-a4').onclick=()=>{if(!selectedBag)return toast('กรุณาเลือกถุงก่อน');window.open('/print-bag.html?bag='+encodeURIComponent(selectedBag),'_blank','noopener')};
 $('sample-csv').onclick=()=>downloadFile('ParcelGuard-Tracking-Sample.csv','\ufefftracking\r\nSPX000012345\r\nSPX000012346\r\n');$('export-audit').onclick=exportAudit;
 $('pair-device').onclick=async()=>{let name=prompt('ตั้งชื่ออุปกรณ์ เช่น Vivo V29 โต๊ะ 1');if(!name)return;try{const r=await api('/api/devices/pair',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({name})});await refresh();openModal('รหัสเชื่อมต่อ '+name,`<p>บันทึกรหัสไว้ตอนนี้เท่านั้น ระบบไม่แสดงรหัสเต็มซ้ำอีก</p><div class="list-section"><div>DEVICE ID: <code>${esc(r.id)}</code></div><div style="overflow-wrap:anywhere;margin-top:10px">LAN TOKEN: <code>${esc(r.token)}</code></div></div><div class="hint-panel"><b>สำคัญ</b><p>Android V0.4.3 Hybrid LAN Pilot ส่งหลักฐานอัตโนมัติได้ขณะเปิดแอปบน Wi-Fi ร้าน หลังกรอก IP และ Token ในตั้งค่า • ใช้เครือข่ายร้านส่วนตัวเท่านั้น อย่าแชร์ Token</p></div>`,'PAIRING TOKEN')}catch(e){toast('เพิ่มอุปกรณ์ไม่ได้: '+e.message)}};
 $('help-btn').onclick=()=>openModal('ParcelGuard PC Hybrid — รุ่น LAN Pilot',`<p>รุ่นนี้เก็บข้อมูลจริงบน PC ผ่าน SQLite แล้ว ไม่ใช่ข้อมูลจำลอง</p><div class="list-section"><h3>ใช้งานได้</h3><div>• นำเข้า ZIP หลักฐานจาก ParcelGuard Android V0.4–V0.4.3</div><div>• ดูรูป/วิดีโอ ค้น Tracking และตรวจถุง</div><div>• นำเข้า CSV รายการที่จะส่งและเช็กขาด/เกิน</div><div>• ลงทะเบียนอุปกรณ์และเปิด LAN API แบบ opt-in</div></div><div class="list-section"><h3>ยังไม่พร้อม</h3><div>• ซิงก์ขณะปิดแอป / background WorkManager ยังไม่รองรับ</div><div>• Cloud Backup / HTTPS / บัญชีผู้ใช้หลายระดับ</div><div>• EXE แบบไม่ต้องติดตั้ง Python</div></div>`,'ABOUT');
 $('mobile-nav').onclick=()=>$('sidebar').classList.toggle('open');$('modal-close').onclick=closeModal;$('modal').onclick=e=>{if(e.target===$('modal'))closeModal()};document.addEventListener('keydown',e=>{if(e.key==='Escape')closeModal()});
 $('import-zip-btn').onclick=()=>$('zip-file').click();$('zip-file').onchange=e=>importZip(e.target.files[0]);$('create-test-bag').onclick=async()=>{let b=prompt('ระบุรหัสถุง เช่น BAG-TEST-01');if(!b)return;let carrier=prompt('ขนส่ง (SPX / Flash / J&T / LEX)','SPX')||'SPX';try{await api('/api/create-bag',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({bag_id:b,carrier})});await refresh();toast('สร้างถุงแล้ว: '+b)}catch(e){toast(e.message)}};
 $('backup-now-btn').onclick=async()=>{const label=$('backup-now-status');label.textContent='กำลังสำรองฐานข้อมูลและหลักฐาน...';$('backup-now-btn').disabled=true;try{const r=await api('/api/backup/create',{method:'POST'});label.textContent='สำรองสำเร็จ: '+r.backup_dir;toast('สำรองข้อมูลเสร็จแล้ว')}catch(e){label.textContent='สำรองไม่สำเร็จ: '+e.message}finally{$('backup-now-btn').disabled=false}};
 $('check-update-btn').onclick=async()=>{const label=$('update-status');label.textContent='กำลังตรวจ...';try{const v=await api('/api/update/check');label.textContent=v.message||(v.update_available?'มีเวอร์ชันใหม่ '+v.latest+' กรุณาขอไฟล์ติดตั้งจากผู้พัฒนา':'ใช้เวอร์ชันล่าสุด '+v.current)}catch(e){label.textContent='ตรวจเวอร์ชันไม่ได้: '+e.message}};
 $('save-settings').onclick=()=>toast('ตั้งค่าซิงก์อัตโนมัติและ Cloud ยังไม่เปิดใช้ในรุ่นนี้');$('reset-demo').onclick=()=>toast('ไม่มีข้อมูลจำลองให้ล้าง ระบบเก็บข้อมูลจริง');
}
wire();fetch('/api/auth/status',{cache:'no-store'}).then(r=>r.json()).then(d=>{if(!d.authenticated){location.href='/login.html';return}window.PG_CSRF=d.csrf;const out=document.createElement('button');out.textContent='ออกจากระบบ Pro';out.style='position:fixed;right:14px;bottom:14px;z-index:1000;padding:10px 15px;background:#243748;color:white;border:1px solid #486075;border-radius:8px;cursor:pointer';out.onclick=async()=>{if(!confirm('ออกจากระบบ ParcelGuard PC? อุปกรณ์ Android จะหยุดส่งข้อมูลจนกว่าจะล็อกอินอีกครั้ง'))return;await api('/api/auth/logout',{method:'POST'});location.href='/login.html'};document.body.appendChild(out);refresh();setInterval(refresh,20000)}).catch(()=>{location.href='/login.html'});

// PC station: USB keyboard-wedge readers send text and Enter to the focused input.
let scannerStream=null, scannerBusy=false;
async function openScannerCamera(){
 try{scannerStream=await navigator.mediaDevices.getUserMedia({video:{width:{ideal:1280},height:{ideal:720}},audio:false});
 $('scan-preview').srcObject=scannerStream;toast('กล้องพร้อมถ่ายหลักฐาน');}
 catch(e){toast('เปิดเว็บแคมไม่ได้: '+e.message)}
}
async function recordShortVideo(camera){
 if(typeof MediaRecorder==='undefined')return '';
 const mime=['video/webm;codecs=vp8','video/webm'].find(t=>MediaRecorder.isTypeSupported(t));
 if(!mime)return '';
 const chunks=[];let recorder;
 try{
  recorder=new MediaRecorder(scannerStream,{mimeType:mime,videoBitsPerSecond:1200000});
  const ended=new Promise((resolve,reject)=>{recorder.ondataavailable=e=>{if(e.data.size)chunks.push(e.data)};recorder.onerror=e=>reject(e.error||Error('MediaRecorder failed'));recorder.onstop=resolve});
  recorder.start();await new Promise(resolve=>setTimeout(resolve,3000));
  if(recorder.state==='recording')recorder.stop();await ended;
  const clip=new Blob(chunks,{type:'video/webm'});
  if(!clip.size||clip.size>18*1024*1024)return '';
  return await new Promise((resolve,reject)=>{const reader=new FileReader();reader.onload=()=>resolve(reader.result);reader.onerror=reject;reader.readAsDataURL(clip)});
 }catch(e){if(recorder?.state==='recording')recorder.stop();toast('อัดคลิปไม่สำเร็จ จะเก็บภาพ JPEG แทน');return ''}
}
async function savePcScan(){
 if(scannerBusy)return;
 const tracking=$('scan-tracking').value.trim(),bag=$('scan-bag').value.trim(),carrier=$('scan-carrier').value;
 if(!tracking||!bag){toast('กรอก Tracking และรหัสถุง');return}
 const camera=$('scan-preview');if(!scannerStream||!camera.videoWidth){toast('ต้องเปิดเว็บแคมเพื่อเก็บหลักฐานก่อน');return}
 scannerBusy=true;$('scan-save').disabled=true;
 try{
  $('scanner-feedback').textContent='กำลังอัดวิดีโอ 3 วินาที แล้วถ่ายภาพ...';
  const video=await recordShortVideo(camera);
  const canvas=$('scan-canvas');canvas.width=camera.videoWidth;canvas.height=camera.videoHeight;
  canvas.getContext('2d').drawImage(camera,0,0,canvas.width,canvas.height);
  const photo=canvas.toDataURL('image/jpeg',0.84);
  const result=await api('/api/pc/scan',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({tracking,bag,carrier,photo,video})});
  $('scanner-feedback').textContent='✓ บันทึก '+result.tracking+' ลงถุง '+result.bag+' สำเร็จ'+(video?' (รูป + วิดีโอ)':' (รูปภาพ)');
  $('scan-tracking').value='';$('scan-tracking').focus();await refresh();
 }catch(e){$('scanner-feedback').textContent='⚠ '+e.message;toast('บันทึกไม่สำเร็จ: '+e.message)}
 finally{scannerBusy=false;$('scan-save').disabled=false}
}
$('scan-camera').onclick=openScannerCamera;
$('scan-save').onclick=savePcScan;
$('scan-tracking').addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();savePcScan()}});

async function updatePairingDiagnostics(){
 try{
  const info=await api('/api/pair/status');
  const el=$('pair-diagnostic');if(!el)return;
  el.textContent='PC LAN '+(info.lan_enabled?'เปิดอยู่':'ปิดอยู่')+' · มือถือที่ลงทะเบียน '+info.paired_devices+' เครื่อง · '+info.last_pairing_result;
  if(info.last_pairing_result.includes('จับคู่สำเร็จ'))await refresh();
 }catch(e){const el=$('pair-diagnostic');if(el)el.textContent='ตรวจสถานะ PC ไม่ได้: '+e.message;}
}
setInterval(()=>{if(document.querySelector('#page-devices.active'))updatePairingDiagnostics()},3000);
let qrCountdown=null;
$('make-pair-qr').onclick=async()=>{
 try{
  const result=await api('/api/pair/new',{method:'POST'});
  if(!result.lan)throw Error('PC ไม่ได้เปิด LAN receiver');
  const el=$('pair-qr-img');el.src='/api/pair/qr?ts='+Date.now();el.style.display='block';
  let left=result.ttl;clearInterval(qrCountdown);
  $('pair-qr-status').textContent='QR พร้อมสแกน · IP '+result.ip+' · เหลือ '+left+' วินาที';updatePairingDiagnostics();
  qrCountdown=setInterval(()=>{left--;if(left<=0){clearInterval(qrCountdown);el.style.display='none';$('pair-qr-status').textContent='QR หมดอายุแล้ว — กดสร้าง QR ใหม่ได้ทันที'}else $('pair-qr-status').textContent='QR พร้อมสแกน · IP '+result.ip+' · เหลือ '+left+' วินาที'},1000);
 }catch(e){toast('สร้าง QR ไม่สำเร็จ: '+e.message)}
};
