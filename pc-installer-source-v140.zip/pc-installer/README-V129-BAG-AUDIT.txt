ParcelGuard PC V1.2.9 - Bag Audit Detail + Print

Changes: Overview review card now shows scanned parcel count as N รายการ; BAG AUDIT popup displays all actually scanned tracking codes from selected bag and has direct A4 print button. Original print-bag route /print-bag.html, Firebase Login, SQLite, QR and sync unchanged.

How to use: close older PC Station, extract separately, run START-PARCELGUARD-PC.bat; open ภาพรวม > ถุงที่ควรตรวจสอบ; click bag, then พิมพ์ใบส่งมอบ A4.

If bag has no scanned items popup explicitly says ยังไม่มีรายการพัสดุในถุงนี้. Scanned count and expected manifest are kept separate.
