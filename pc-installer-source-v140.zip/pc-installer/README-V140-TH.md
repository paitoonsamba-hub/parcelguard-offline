# ParcelGuard PC V1.4.0 — Windows Installer & Updates (PILOT)

**ยังไม่ได้สร้างหรือรับรอง EXE Installer สำหรับลูกค้า** — ชุดนี้มีซอร์สที่ทดสอบแล้วและสูตร Build สำหรับ Windows เท่านั้น บิลด์ EXE ด้วย GitHub Actions หรือบน Windows ที่มี Python 3.12 (เครื่องผู้พัฒนาเท่านั้น) และ Inno Setup 6.4.3 แล้วทดสอบตัวติดตั้งบนเครื่องใหม่ก่อนขาย

## ไม่กระทบรุ่นล่าสุดที่ใช้งานได้

- อ้างอิงโดยตรงจาก `ParcelGuard_PC_Station_V1_3_0_Commercial_Security_PILOT.zip` ที่ผ่านการ Login Pro และผูก PC บน Firebase จริง
- **ไม่แก้ V1.2.9 Stable หรือฐานข้อมูล Stable** ใน `%LOCALAPPDATA%\ParcelGuardPC`
- V1.4.0 Pilot **ใช้ข้อมูลชุดเดียวกับ V1.3.0 Pilot** คือ `%LOCALAPPDATA%\ParcelGuardPC-Pilot-V130` เพื่อรักษาการจับคู่และ License เดิม; สำรองก่อนอัปเดตเสมอ
- ตัวติดตั้งใช้โฟลเดอร์โปรแกรม `%LOCALAPPDATA%\Programs\ParcelGuard PC Commercial` และไม่มีคำสั่งลบข้อมูลผู้ใช้
- ใช้ `--onedir` ของ PyInstaller รวม Python/แพ็กเกจไว้ใน EXE: ลูกค้าไม่ต้องติดตั้ง Python

## ฟังก์ชันใหม่

1. `installer/ParcelGuard.iss`: สร้าง EXE installer, คลิกติดตั้งและสร้างไอคอน เรียกสคริปต์ตรวจสอบและสำรองข้อมูลก่อนคัดลอกไฟล์
2. `installer/preinstall-backup.ps1`: ตรวจพอร์ต 8765/8766, ปฏิเสธอัปเดตเมื่อโปรแกรมยังทำงาน, สำรองข้อมูลพร้อม media ไว้ `%LOCALAPPDATA%\ParcelGuardPC-Backups\pre-v140-*` และตรวจไฟล์คัดลอกครบ
3. เมนูตั้งค่า > **สำรองข้อมูลตอนนี้**: SQLite Online Backup ผ่าน `Connection.backup()` และก๊อปรูป/วิดีโอไปโฟลเดอร์ Backup โดยไม่แก้ฐานข้อมูลเดิม
4. เมนูตั้งค่า > **ตรวจเวอร์ชันใหม่**: ขอ `https://parcelguard-license.web.app/pc-version.json` ด้วย HTTPS แบบอ่านอย่างเดียว ไม่มีการดาวน์โหลดติดตั้งอัตโนมัติ หากยังไม่ได้เผยแพร่ manifest จะแสดงว่าไม่สามารถตรวจได้ ไม่อ้างว่าเป็นรุ่นล่าสุด
5. ไม่เขียนทับไฟล์ `%LOCALAPPDATA%\ParcelGuardPC` ของ Stable; ถอนโปรแกรมแล้วข้อมูลยังคงอยู่

## วิธีสร้าง Installer บน Windows (เครื่องผู้พัฒนา)

- ติดตั้ง Python 3.12 และ Inno Setup 6.4.3 จากผู้พัฒนาอย่างเป็นทางการ
- จากโฟลเดอร์นี้เรียก `BUILD-WINDOWS.bat` เพื่อสร้าง `dist\ParcelGuardPC\ParcelGuardPC.exe` (Python ถูกบรรจุรวมแล้ว)
- เปิด `installer\ParcelGuard.iss` ด้วย Inno Setup Compiler แล้ว Build เพื่อสร้าง `output\ParcelGuard-PC-Setup-V1.4.0-PILOT.exe`
- หรือเก็บโฟลเดอร์นี้ไว้ที่ `pc-installer/` ใน GitHub Branch `feature/windows-installer-v1.4.0` พร้อม Workflow `.github/workflows/build-installer.yml` แล้วเปิด Actions → Build ParcelGuard PC V1.4.0 Installer → Run workflow

**ยังไม่ต้องคัดลอกไฟล์ใดไปทับ V1.3.0 ที่ทดสอบผ่านแล้ว** โปรแกรมใหม่ต้องรันจากไฟล์ติดตั้งใหม่เท่านั้นหลังตรวจผ่าน

## เงื่อนไขก่อนขาย

- ติดตั้ง/ถอน/ติดตั้งซ้ำทดสอบบน Windows 10/11 x64, ต้องไม่ขอ Python
- ทดสอบ Backup ในเครื่องมี SQLite WAL และภาพ/วิดีโอหลาย GB, มีพื้นที่เพียงพอ
- สแกน USB, กล้อง, QR Sync, พิมพ์ A4, Login Pro บนเครื่องที่เคยผูกสิทธิ์, ยกเลิกสิทธิ์และ Firestore ตามรุ่นก่อน
- ทดสอบการติดตั้งอัปเดตขณะโปรแกรมเปิดอยู่: ต้องไม่เขียนทับไฟล์ใด
- SmartScreen ของ Windows อาจเตือนตัวติดตั้งที่ยังไม่ลงลายเซ็นดิจิทัล **ห้ามบอกลูกค้าให้ปิด SmartScreen** ต้องลงลายเซ็นและสร้างชื่อเสียงการดาวน์โหลดก่อนปล่อยทั่วไป
- Cloud Functions Commercial มีข้อจำกัด security pilot เช่น Device ID คัดลอกข้ามเครื่องได้ และ HTTP LAN ยังไม่เข้ารหัส ต้องแก้ก่อนใช้งานจริงวงกว้าง

## ตรวจแบบไม่แตะ Firebase

```sh
python -m unittest discover -s tests -p 'test_*.py' -v
python -m py_compile server.py run_pc.py
```
