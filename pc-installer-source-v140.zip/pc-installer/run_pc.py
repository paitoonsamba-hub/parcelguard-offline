"""Windows PyInstaller entrypoint: preserve ParcelGuard PC V1.3 server behavior."""
import os
import sys
from pathlib import Path

# Never install data in Program Files or beside executable.
if os.name == 'nt':
    os.environ.setdefault('PARCELGUARD_DATA_DIR', str(Path(os.environ['LOCALAPPDATA'])/'ParcelGuardPC-Pilot-V130'))

from server import main

if __name__ == '__main__':
    sys.argv.insert(1, '--lan')
    main()
