ParcelGuard PC Station V1.2.3 — Login UI Cleanup

Removed redundant “กรอกอีเมล” focus button and helper status message.
Email, password, Firebase Pro authentication and dashboard routing unchanged.
Run START-PARCELGUARD-PC.bat and refresh http://127.0.0.1:8765 with Ctrl+F5.
Do not delete previous parcel database or media.
