@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>&1
if errorlevel 1 (
 echo Python required ONLY ON THE BUILD COMPUTER, not on customer computers.
 exit /b 1
)
py -3.12 -m pip install --disable-pip-version-check -r requirements.txt pyinstaller==6.16.0
if errorlevel 1 exit /b 1
py -3.12 -m PyInstaller --noconfirm --clean --onedir --console --name ParcelGuardPC --add-data "web;web" run_pc.py
if errorlevel 1 exit /b 1
echo Build complete: dist\ParcelGuardPC\ParcelGuardPC.exe
