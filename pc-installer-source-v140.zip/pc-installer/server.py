"""ParcelGuard PC: localhost-first offline server and an opt-in LAN ingest endpoint.
Python 3.10+ standard library only. Android V0.4.3 can upload evidence over opt-in private LAN; no cloud integration.
"""
from __future__ import annotations
import argparse
import base64
import time
import csv
from datetime import datetime, timezone, timedelta
import hashlib
import hmac
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import io
import json
import mimetypes
import os
from pathlib import Path
import re
import secrets
import shutil
import sqlite3
import socket
import tempfile
import threading
import urllib.parse
import urllib.request
import urllib.error
import webbrowser
import zipfile

APP = Path(__file__).resolve().parent
APP_VERSION = '1.4.0'
UPDATE_MANIFEST_URL = 'https://parcelguard-license.web.app/pc-version.json'
WEB = APP / 'web'
DEFAULT_DATA = Path(os.environ.get('PARCELGUARD_DATA_DIR') or ((Path(os.environ['LOCALAPPDATA']) / 'ParcelGuardPC') if os.name == 'nt' and os.environ.get('LOCALAPPDATA') else Path.home() / '.parcelguard_pc'))
MAX_UPLOAD = 250 * 1024 * 1024
MAX_TOTAL_UNCOMPRESSED = 750 * 1024 * 1024
MAX_FILE = 130 * 1024 * 1024
ALLOWED_EXT = {'.jpg', '.jpeg', '.png', '.mp4', '.webm'}
DB_LOCK = threading.RLock()
QR_LOCK = threading.RLock()
QR_STATE = {'code':'','until':0.0, 'issued_at':0.0, 'last_result':'ยังไม่ได้สร้าง QR'}

# Login sessions are process-local, HttpOnly, and never written to disk.
FIREBASE_API_KEY = 'AIzaSyA_6ZpRrMV1iH9dtAxB4pEvuhqkB2dysO8'
FIREBASE_SIGNIN = 'https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=' + FIREBASE_API_KEY
FIREBASE_ACCESS = 'https://asia-southeast1-parcelguard-license.cloudfunctions.net/checkAccess'
COMMERCIAL_ACCESS = 'https://asia-southeast1-parcelguard-license.cloudfunctions.net/commercialCheckPc'
FIREBASE_REFRESH = 'https://securetoken.googleapis.com/v1/token?key=' + FIREBASE_API_KEY
RECHECK_SECONDS = 15 * 60
AUTH_LOCK = threading.RLock()
SESSIONS = {}  # sha256(cookie) -> {csrf, email, expires}
SESSION_SECONDS = 8 * 3600


def firebase_post(url, payload, token=None):
    raw = json.dumps(payload, separators=(',', ':')).encode('utf-8')
    headers={'Content-Type':'application/json','Accept':'application/json'}
    if token: headers['Authorization']='Bearer '+token
    request=urllib.request.Request(url,data=raw,headers=headers,method='POST')
    try:
        with urllib.request.urlopen(request,timeout=12) as response:
            return json.loads(response.read(32768))
    except urllib.error.HTTPError as error:
        raise ValueError('Firebase ปฏิเสธการเข้าสู่ระบบหรือสิทธิ์ Pro (HTTP %s)'%error.code) from None
    except (urllib.error.URLError,TimeoutError):
        raise ValueError('ติดต่อ Firebase ไม่ได้ โปรดตรวจอินเทอร์เน็ต') from None


def verify_pro_login(email,password):
    if not (isinstance(email,str) and isinstance(password,str) and 3<=len(email)<=254 and 1<=len(password)<=1024):
        raise ValueError('กรอกอีเมลและรหัสผ่าน')
    signed=firebase_post(FIREBASE_SIGNIN, {'email':email.strip(),'password':password,'returnSecureToken':True})
    jwt=signed.get('idToken')
    if not jwt: raise ValueError('Firebase ไม่ส่ง ID Token')
    result=firebase_post(FIREBASE_ACCESS, {'data':{}},jwt).get('result',{})
    if not (result.get('active') is True and result.get('lifetime') is True and
            result.get('plan')=='pro' and 'windows' in result.get('features',[])):
        raise ValueError('บัญชีนี้ไม่มีสิทธิ์ ParcelGuard Pro ฿990 สำหรับ Windows')
    return signed.get('email',email.strip())



def pc_device_hash(data_dir=DEFAULT_DATA):
    """Random per-install ID stored outside the app install ZIP and database."""
    root=Path(data_dir);root.mkdir(parents=True,exist_ok=True)
    identity=root/'commercial-device-id'
    if not identity.exists():
        import uuid
        # Exclusive create is safe across concurrent instances.
        try:
            with identity.open('x',encoding='ascii') as f:
                f.write(uuid.uuid4().hex)
            if os.name!='nt':identity.chmod(0o600)
        except FileExistsError:pass
    value=identity.read_text(encoding='ascii').strip()
    if not re.fullmatch(r'[0-9a-f]{32}',value):raise ValueError('PC device identity damaged; contact support')
    return hashlib.sha256(value.encode('ascii')).hexdigest()


def commercial_check(jwt, device_hash):
    response=firebase_post(COMMERCIAL_ACCESS,{'data':{'deviceHash':device_hash}},jwt)
    result=response.get('result',{})
    if result.get('authorized') is not True or result.get('plan')!='pro':
        raise ValueError('ไม่ได้รับสิทธิ์ Commercial Pro บน PC เครื่องนี้')
    return result


def verify_commercial_login(email,password,data_dir=DEFAULT_DATA):
    if not(isinstance(email,str) and isinstance(password,str) and 3<=len(email)<=254 and 1<=len(password)<=1024):
        raise ValueError('กรอกอีเมลและรหัสผ่าน')
    signed=firebase_post(FIREBASE_SIGNIN,{'email':email.strip(),'password':password,'returnSecureToken':True})
    if not signed.get('idToken') or not signed.get('refreshToken'):
        raise ValueError('Firebase ไม่ส่งข้อมูลเข้าสู่ระบบที่จำเป็น')
    device=pc_device_hash(data_dir)
    commercial_check(signed['idToken'],device)
    return {'email':signed.get('email',email.strip()),'idToken':signed['idToken'],
            'refreshToken':signed['refreshToken'],'deviceHash':device,
            'tokenExpires':time.monotonic()+max(60,int(signed.get('expiresIn',3600))-120)}


def refresh_commercial_session(record):
    """Fail closed on revocation or connectivity loss. Only tokens in RAM."""
    with record['lock']:
        if record['expires']<=time.monotonic():return False
        if record['next_check']>time.monotonic():return True
        try:
            if time.monotonic()>=record['tokenExpires']:
                payload=urllib.parse.urlencode({'grant_type':'refresh_token','refresh_token':record['refreshToken']}).encode('ascii')
                request=urllib.request.Request(FIREBASE_REFRESH,data=payload,method='POST')
                with urllib.request.urlopen(request,timeout=12) as response:
                    tokens=json.loads(response.read(32768))
                record['idToken']=tokens['id_token']
                record['refreshToken']=tokens['refresh_token']
                record['tokenExpires']=time.monotonic()+max(60,int(tokens.get('expires_in',3600))-120)
            commercial_check(record['idToken'],record['deviceHash'])
            record['next_check']=time.monotonic()+RECHECK_SECONDS
            return True
        except (ValueError,KeyError,urllib.error.URLError,TimeoutError,OSError):
            record['next_check']=0
            return False


def new_session(email,credentials=None):
    token=secrets.token_urlsafe(40)
    record={'email':email,'csrf':secrets.token_urlsafe(24),'expires':time.monotonic()+SESSION_SECONDS}
    if credentials:
        record.update(credentials)
        record['next_check']=time.monotonic()+RECHECK_SECONDS
        record['lock']=threading.RLock()
    with AUTH_LOCK:
        SESSIONS[hashlib.sha256(token.encode()).hexdigest()]=record
    return token,record


def session_for(cookie_header):
    import http.cookies
    try:
        jar=http.cookies.SimpleCookie();jar.load(cookie_header or '')
        token=jar['pg_session'].value if 'pg_session' in jar else ''
        if not token:return None
        key=hashlib.sha256(token.encode()).hexdigest()
    except Exception:return None
    with AUTH_LOCK:
        record=SESSIONS.get(key)
    if not record or record['expires']<=time.monotonic():
        with AUTH_LOCK:SESSIONS.pop(key,None)
        return None
    if 'refreshToken' in record and not refresh_commercial_session(record):
        with AUTH_LOCK:SESSIONS.pop(key,None)
        return None
    return record


def owner_logged_in():
    with AUTH_LOCK:
        tokens=list(SESSIONS.items())
    for key,record in tokens:
        if record['expires']>time.monotonic() and (not 'refreshToken' in record or refresh_commercial_session(record)):
            return True
        with AUTH_LOCK:SESSIONS.pop(key,None)
    return False


def now_ms(): return int(datetime.now(timezone.utc).timestamp() * 1000)


def normalized_code(value):
    code = str(value or '').strip()
    if not 3 <= len(code) <= 120 or any(ord(c) < 32 for c in code):
        raise ValueError('รหัส Tracking ไม่ถูกต้อง')
    return code


def bag_key(device_id, bag_id): return device_id + '|' + bag_id


def parse_csv_bytes(raw, mode='manifest'):
    if len(raw) > MAX_UPLOAD: raise ValueError('ไฟล์ใหญ่เกินไป')
    try:
        content = raw.decode('utf-8-sig')
    except UnicodeDecodeError:
        try: content = raw.decode('cp874')
        except UnicodeDecodeError: raise ValueError('CSV ต้องเป็น UTF-8 หรือ Windows Thai')
    sample = content[:4096]
    try: sep = csv.Sniffer().sniff(sample, delimiters=',;\t').delimiter
    except csv.Error: sep = '\t' if '\t' in sample else (';' if sample.count(';') > sample.count(',') else ',')
    rows = list(csv.reader(io.StringIO(content), delimiter=sep))
    rows = [r for r in rows if any(c.strip() for c in r)]
    if not rows: raise ValueError('CSV ว่าง')
    if mode == 'expected':
        header = [x.strip().lower() for x in rows[0]]
        choices = {'tracking','tracking_number','เลขพัสดุ','เลขติดตาม','awb'}
        index = next((i for i,x in enumerate(header) if x in choices), 0)
        start = 1 if header[index] in choices else 0
        codes = []
        seen = set()
        for row in rows[start:]:
            if index >= len(row) or not row[index].strip(): continue
            code = normalized_code(row[index])
            if code in seen: raise ValueError('มีเลข Tracking ซ้ำในไฟล์: '+code)
            codes.append(code); seen.add(code)
        if not codes: raise ValueError('ไม่พบเลข Tracking ในไฟล์')
        if len(codes)>100000: raise ValueError('จำนวน Tracking เกินขีดจำกัด')
        return codes
    if mode == 'manifest':
        expected = {'tracking','bag','photo_name','scanned_at'}
        keys = [x.strip().lower() for x in rows[0]]
        if not expected.issubset(keys): raise ValueError('ไม่พบคอลัมน์ manifest.csv ตามรูปแบบ ParcelGuard Android')
        output=[]
        for row in rows[1:]:
            item={keys[i]:row[i].strip() if i<len(row) else '' for i in range(len(keys))}
            item['tracking']=normalized_code(item['tracking'])
            item['bag']=normalized_code(item['bag'])
            try: item['scanned_at'] = int(item['scanned_at'])
            except ValueError: item['scanned_at'] = now_ms()
            output.append(item)
        return output
    raise ValueError('unknown mode')


class Store:
    def __init__(self, data_dir):
        self.data = Path(data_dir)
        self.data.mkdir(parents=True, exist_ok=True)
        self.media = self.data / 'media'; self.media.mkdir(exist_ok=True)
        self.db_path = self.data / 'parcelguard-pc.sqlite3'
        self.conn = sqlite3.connect(self.db_path, check_same_thread=False, timeout=25)
        self.conn.row_factory = sqlite3.Row
        self.conn.execute('PRAGMA foreign_keys = ON')
        self.conn.execute('PRAGMA journal_mode = WAL')
        self.conn.executescript('''
CREATE TABLE IF NOT EXISTS devices(id TEXT PRIMARY KEY, name TEXT NOT NULL, token_sha256 TEXT, last_seen INTEGER, paired_at INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS bags(key TEXT PRIMARY KEY, bag_id TEXT NOT NULL, device_id TEXT NOT NULL REFERENCES devices(id), carrier TEXT NOT NULL, closed INTEGER NOT NULL DEFAULT 0, created_at INTEGER NOT NULL, UNIQUE(device_id, bag_id));
CREATE TABLE IF NOT EXISTS parcels(device_id TEXT NOT NULL REFERENCES devices(id), tracking TEXT NOT NULL, bag_key TEXT NOT NULL REFERENCES bags(key), scanned_at INTEGER NOT NULL, photo_sha TEXT DEFAULT '', video_sha TEXT DEFAULT '', PRIMARY KEY(device_id,tracking));
CREATE TABLE IF NOT EXISTS expected(bag_key TEXT NOT NULL REFERENCES bags(key), tracking TEXT NOT NULL, PRIMARY KEY(bag_key,tracking));
CREATE TABLE IF NOT EXISTS media(sha TEXT PRIMARY KEY, ext TEXT NOT NULL, size INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS imports(sha TEXT PRIMARY KEY, device_id TEXT NOT NULL, at INTEGER NOT NULL, count INTEGER NOT NULL);
''')
        self.conn.execute("INSERT OR IGNORE INTO devices(id,name,paired_at) VALUES('pc','PC / นำเข้าด้วยตนเอง',?)",(now_ms(),))
        self.conn.commit()

    def backup_now(self, backup_root=None):
        """Transactional SQLite backup and media copy, never alter live data.

        Called only from authenticated same-origin UI. Keeps backups outside the
        app and the live data folder; includes WAL database contents correctly.
        """
        root=Path(backup_root or (self.data.parent / 'ParcelGuardPC-Backups'))
        root.mkdir(parents=True,exist_ok=True)
        dest=root / ('manual-v140-' + datetime.now().strftime('%Y%m%d-%H%M%S') + '-' + secrets.token_hex(3))
        dest.mkdir()
        try:
            with DB_LOCK:
                with sqlite3.connect(dest / 'parcelguard-pc.sqlite3') as copied:
                    self.conn.backup(copied)
                if self.media.exists():
                    shutil.copytree(self.media,dest / 'media')
                for file in self.data.iterdir():
                    if file.is_file() and file.name not in ('parcelguard-pc.sqlite3','parcelguard-pc.sqlite3-wal','parcelguard-pc.sqlite3-shm'):
                        shutil.copy2(file,dest / file.name)
            with sqlite3.connect(dest / 'parcelguard-pc.sqlite3') as check:
                if check.execute('PRAGMA integrity_check').fetchone()[0]!='ok':
                    raise RuntimeError('สำรองฐานข้อมูลไม่สมบูรณ์')
            return {'ok':True,'backup_dir':str(dest),'database':'parcelguard-pc.sqlite3'}
        except Exception:
            shutil.rmtree(dest,ignore_errors=True)
            raise

    def close(self):
        with DB_LOCK: self.conn.close()

    def connect_device(self, name):
        name = str(name or '').strip()[:60]
        if not name: raise ValueError('กรุณากรอกชื่อมือถือ')
        device_id = secrets.token_hex(8)
        token = secrets.token_urlsafe(32)
        with DB_LOCK:
            self.conn.execute('INSERT INTO devices(id,name,token_sha256,last_seen,paired_at) VALUES(?,?,?,?,?)', (device_id,name,hashlib.sha256(token.encode()).hexdigest(),None,now_ms()))
            self.conn.commit()
        return {'id':device_id,'name':name,'token':token}

    def auth_device(self, token):
        if not token: return None
        token_hash=hashlib.sha256(token.encode()).hexdigest()
        with DB_LOCK:
            rows=self.conn.execute('SELECT id,token_sha256 FROM devices WHERE token_sha256 IS NOT NULL').fetchall()
        for row in rows:
            if hmac.compare_digest(row['token_sha256'],token_hash): return row['id']
        return None

    def devices(self):
        with DB_LOCK:
            rows=self.conn.execute('SELECT id,name,last_seen,paired_at FROM devices ORDER BY paired_at DESC').fetchall()
        return [dict(r) for r in rows]

    def ensure_bag(self, device_id, bag_id, carrier='Unknown', when=None):
        k=bag_key(device_id,bag_id)
        self.conn.execute('INSERT OR IGNORE INTO bags(key,bag_id,device_id,carrier,created_at) VALUES(?,?,?,?,?)',(k,bag_id,device_id,str(carrier or 'Unknown')[:30],when or now_ms()))
        return k

    def create_test_bag(self, bag_id, carrier):
        bag_id=normalized_code(bag_id)
        carrier=str(carrier or 'SPX').strip()[:30]
        with DB_LOCK:
            k=self.ensure_bag('pc',bag_id,carrier)
            self.conn.commit()
        return {'key':k,'bag_id':bag_id}

    def pc_scan(self, tracking, bag, carrier, photo_data, video_data=''):
        """Insert PC-origin evidence through the same validated ZIP/SQLite ingestion pipeline."""
        tracking = normalized_code(tracking)
        bag = normalized_code(bag)
        carrier = str(carrier or 'SPX').strip()[:30]
        if carrier not in ('SPX', 'LEX-ALL', 'LEX', 'Flash', 'J&T', 'Other'):
            raise ValueError('ขนส่งไม่ถูกต้อง')
        # Avoid silently replacing existing evidence on a duplicate scanner read.
        with DB_LOCK:
            if self.conn.execute('SELECT 1 FROM parcels WHERE device_id=? AND tracking=?', ('pc', tracking)).fetchone():
                raise ValueError('Tracking นี้สแกนบน PC แล้ว — ไม่บันทึกซ้ำ')
        def decode_data_uri(uri, prefix, max_bytes):
            if not isinstance(uri, str) or not uri.startswith(prefix):
                raise ValueError('รูปแบบหลักฐานจากกล้องไม่ถูกต้อง')
            encoded = uri[len(prefix):]
            if len(encoded) > (max_bytes * 4 // 3) + 8:
                raise ValueError('ไฟล์กล้องใหญ่เกินที่กำหนด')
            try: data=base64.b64decode(encoded, validate=True)
            except (ValueError, base64.binascii.Error):raise ValueError('ข้อมูลกล้องไม่ถูกต้อง')
            if not data or len(data)>max_bytes:raise ValueError('ไฟล์หลักฐานว่างหรือใหญ่เกิน')
            return data
        photo = decode_data_uri(photo_data, 'data:image/jpeg;base64,', 10*1024*1024)
        # JPEG magic-byte validation avoids accidentally storing arbitrary files as images.
        if not (photo.startswith(b'\xff\xd8') and photo.endswith(b'\xff\xd9')):
            raise ValueError('ไฟล์ภาพต้องเป็น JPEG')
        video = b''
        if video_data:
            video = decode_data_uri(video_data, 'data:video/webm;base64,', 18*1024*1024)
            if not video.startswith(b'\x1a\x45\xdf\xa3'):
                raise ValueError('ไฟล์วิดีโอต้องเป็น WebM')
        safe = re.sub('[^A-Za-z0-9_-]', '_', tracking)
        photo_name = 'photos/'+safe+'.jpg'
        video_name = 'videos/parcels/'+safe+'.webm' if video else ''
        manifest=io.StringIO();writer=csv.writer(manifest)
        writer.writerow(['tracking','bag','photo_name','scanned_at','video_offset_ms','parcel_video_file','video_status','carrier'])
        writer.writerow([tracking,bag,photo_name,now_ms(),-1,video_name,2 if video else 0,carrier])
        zipped=io.BytesIO()
        with zipfile.ZipFile(zipped,'w',compression=zipfile.ZIP_DEFLATED) as archive:
            archive.writestr(photo_name,photo)
            if video:archive.writestr(video_name,video)
            archive.writestr('manifest.csv',manifest.getvalue())
            sums=hashlib.sha256(photo).hexdigest()+'  '+photo_name+'\n'
            if video:sums+=hashlib.sha256(video).hexdigest()+'  '+video_name+'\n'
            archive.writestr('SHA256SUMS.txt',sums)
        result=self.ingest_zip(zipped.getvalue(),'pc')
        return {'ok':True,'tracking':tracking,'bag':bag,'imported':result.get('imported',0)}

    def set_expected(self, key, csv_bytes):
        codes=parse_csv_bytes(csv_bytes,'expected')
        with DB_LOCK:
            if not self.conn.execute('SELECT 1 FROM bags WHERE key=?',(key,)).fetchone(): raise KeyError('ไม่พบถุงนี้')
            self.conn.execute('DELETE FROM expected WHERE bag_key=?',(key,))
            self.conn.executemany('INSERT INTO expected(bag_key,tracking) VALUES(?,?)',[(key,code) for code in codes])
            self.conn.commit()
        return len(codes)

    def ingest_zip(self, contents, device_id='pc'):
        if not contents or len(contents)>MAX_UPLOAD: raise ValueError('ZIP ใหญ่เกิน 250 MB')
        zip_sha=hashlib.sha256(contents).hexdigest()
        with DB_LOCK:
            existing=self.conn.execute('SELECT count FROM imports WHERE sha=?',(zip_sha,)).fetchone()
            if existing: return {'imported':0,'skipped':existing['count'],'already_imported':True}
            device=self.conn.execute('SELECT id FROM devices WHERE id=?',(device_id,)).fetchone()
            if not device: raise ValueError('อุปกรณ์ไม่อยู่ในระบบ')
        with zipfile.ZipFile(io.BytesIO(contents)) as z:
            if len(z.infolist())>25000: raise ValueError('ไฟล์ ZIP มีไฟล์ย่อยมากเกินไป')
            total=sum(x.file_size for x in z.infolist())
            if total>MAX_TOTAL_UNCOMPRESSED: raise ValueError('ZIP แตกแล้วใหญ่เกินขีดจำกัด')
            for entry in z.infolist():
                pp=Path(entry.filename.replace('\\','/'))
                if entry.file_size>MAX_FILE or entry.filename.startswith('/') or '..' in pp.parts or '\\' in entry.filename:
                    raise ValueError('ชื่อไฟล์ ZIP ไม่ปลอดภัยหรือไฟล์ใหญ่เกินไป')
            names=set(z.namelist())
            if 'manifest.csv' not in names: raise ValueError('ZIP ไม่มี manifest.csv')
            rows=parse_csv_bytes(z.read('manifest.csv'),'manifest')
            expected_hashes={}
            if 'SHA256SUMS.txt' in names:
                text=z.read('SHA256SUMS.txt').decode('utf-8-sig')
                for line in text.splitlines():
                    p=line.strip().split(None,1)
                    if len(p)==2 and re.fullmatch('[0-9a-fA-F]{64}',p[0]):expected_hashes[p[1].strip()]=p[0].lower()
            binaries={}
            for item in rows:
                for label in ('photo_name','parcel_video_file'):
                    path=item.get(label,'')
                    if not path: continue
                    if path not in names: continue
                    ext=Path(path).suffix.lower()
                    if ext not in ALLOWED_EXT: continue
                    if path not in binaries:
                        blob=z.read(path)
                        sha=hashlib.sha256(blob).hexdigest()
                        if path in expected_hashes and expected_hashes[path]!=sha:raise ValueError('checksum ผิดพลาด: '+path)
                        binaries[path]=(sha,ext,blob)
            # Validate everything before writing. Media is content-addressed and idempotent.
            with DB_LOCK:
                created_files=[]
                try:
                    self.conn.execute('BEGIN IMMEDIATE')
                    count=0
                    for item in rows:
                        bag_id=item['bag']; track=item['tracking']
                        k=self.ensure_bag(device_id,bag_id, item.get('carrier') or 'Unknown', item['scanned_at'])
                        photo_sha=binaries.get(item.get('photo_name',''),('',None,None))[0]
                        video_sha=binaries.get(item.get('parcel_video_file',''),('',None,None))[0]
                        self.conn.execute('INSERT INTO parcels(device_id,tracking,bag_key,scanned_at,photo_sha,video_sha) VALUES(?,?,?,?,?,?) ON CONFLICT(device_id,tracking) DO UPDATE SET photo_sha=CASE WHEN excluded.photo_sha!="" THEN excluded.photo_sha ELSE parcels.photo_sha END, video_sha=CASE WHEN excluded.video_sha!="" THEN excluded.video_sha ELSE parcels.video_sha END',(device_id,track,k,item['scanned_at'],photo_sha,video_sha))
                        count+=1
                    for sha,ext,blob in binaries.values():
                        folder=self.media/sha[:2];folder.mkdir(exist_ok=True)
                        dest=folder/(sha+ext)
                        if not dest.is_file():
                            # Write using a temporary name to avoid leaving a half-written evidence file.
                            tmp=folder/(sha+'.uploading-'+secrets.token_hex(4))
                            try:
                                tmp.write_bytes(blob)
                                os.replace(tmp,dest)
                                created_files.append(dest)
                            finally:
                                if tmp.exists():tmp.unlink()
                        self.conn.execute('INSERT OR IGNORE INTO media(sha,ext,size) VALUES(?,?,?)',(sha,ext,len(blob)))
                    self.conn.execute('INSERT INTO imports(sha,device_id,at,count) VALUES(?,?,?,?)',(zip_sha,device_id,now_ms(),count))
                    self.conn.execute('UPDATE devices SET last_seen=? WHERE id=?',(now_ms(),device_id))
                    self.conn.commit()
                except Exception:
                    self.conn.rollback()
                    for p in created_files:
                        try:p.unlink()
                        except OSError:pass
                    raise
            return {'imported':count,'files':len(binaries),'already_imported':False}

    def bags(self):
        with DB_LOCK:
            rows=[dict(x) for x in self.conn.execute('''SELECT b.*,d.name as device_name FROM bags b JOIN devices d ON b.device_id=d.id ORDER BY b.created_at DESC''')]
            for b in rows:
                b['scanned']=[r['tracking'] for r in self.conn.execute('SELECT tracking FROM parcels WHERE bag_key=? ORDER BY scanned_at',(b['key'],))]
                b['expected']=[r['tracking'] for r in self.conn.execute('SELECT tracking FROM expected WHERE bag_key=?',(b['key'],))]
                b['manifest_loaded']=bool(b['expected'])
                s=set(b['scanned']);e=set(b['expected'])
                b['missing']=sorted(e-s);b['extra']=sorted(s-e) if e else []
                b['verified']=bool(e) and not b['missing'] and not b['extra']
        return rows

    def parcels(self, query='',carrier='all', limit=300):
        params=[]
        sql='''SELECT p.device_id,p.tracking,p.bag_key,p.scanned_at,p.photo_sha,p.video_sha,b.bag_id,b.carrier,d.name as device_name FROM parcels p JOIN bags b ON b.key=p.bag_key JOIN devices d ON d.id=p.device_id WHERE 1=1'''
        if query:
            sql+=' AND (p.tracking LIKE ? ESCAPE "\\" OR b.bag_id LIKE ? ESCAPE "\\")'
            val='%'+query.replace('\\','\\\\').replace('%','\\%').replace('_','\\_')+'%';params.extend([val,val])
        if carrier!='all': sql+=' AND b.carrier=?';params.append(carrier)
        sql+=' ORDER BY p.scanned_at DESC LIMIT ?';params.append(limit)
        with DB_LOCK:
            return [dict(x) for x in self.conn.execute(sql,params)]

    def media_location(self, sha):
        if not re.fullmatch('[0-9a-f]{64}',sha):return None
        with DB_LOCK:
            row=self.conn.execute('SELECT ext FROM media WHERE sha=?',(sha,)).fetchone()
        if not row: return None
        p=self.media/sha[:2]/(sha+row['ext'])
        return p if p.is_file() else None

    def summary(self):
        bags=self.bags();scans=self.parcels(limit=10000)
        stats={'scanned':sum(len(x['scanned']) for x in bags),'bags':len(bags),'closed':sum(x['closed'] for x in bags),'need_review':sum(not x['verified'] for x in bags),'verified':sum(x['verified'] for x in bags)}
        return {'stats':stats,'bags':bags,'recent':scans[:30],'devices':self.devices(),'cloud':'not_configured','storage':str(self.data)}


def lan_ip():
    s=socket.socket(socket.AF_INET,socket.SOCK_DGRAM)
    try:
        s.connect(('192.0.2.1',80))
        return s.getsockname()[0]
    except OSError:return '127.0.0.1'
    finally:s.close()


def make_handler(store, mode='local'):
    class Handler(BaseHTTPRequestHandler):
        server_version='ParcelGuardPC/1.4.0-installer-pilot'
        def log_message(self, fmt, *args):
            print('[%s] %s'%(mode,fmt%args))
        def respond(self, status, value, content_type='application/json; charset=utf-8',extra=None):
            raw = json.dumps(value,ensure_ascii=False).encode('utf-8') if content_type.startswith('application/json') else value
            self.send_response(status)
            self.send_header('Content-Type',content_type)
            self.send_header('Content-Length',str(len(raw)))
            self.send_header('X-Content-Type-Options','nosniff')
            self.send_header('Cache-Control','no-store')
            self.send_header('Referrer-Policy','no-referrer')
            self.send_header('Content-Security-Policy',"default-src 'self'; img-src 'self' data:; style-src 'self' 'unsafe-inline'; script-src 'self'; object-src 'none'; base-uri 'none'; frame-ancestors 'none'")
            if extra:
                for k,v in extra.items():self.send_header(k,v)
            self.end_headers();self.wfile.write(raw)
        def read_body(self):
            length=self.headers.get('Content-Length','')
            if not length.isdigit():raise ValueError('ไม่พบขนาดข้อมูล')
            n=int(length)
            if n<0 or n>MAX_UPLOAD:raise ValueError('ไฟล์ใหญ่เกิน 250 MB')
            data=self.rfile.read(n)
            if len(data)!=n:raise ValueError('ไฟล์ส่งมาไม่ครบ')
            return data
        def authorize(self):
            hdr=self.headers.get('Authorization','')
            if not hdr.startswith('Bearer '):return None
            return store.auth_device(hdr[7:])
        def do_GET(self):
            parsed=urllib.parse.urlsplit(self.path)
            path=parsed.path
            query=urllib.parse.parse_qs(parsed.query)
            try:
                if mode=='lan':
                    if path=='/api/device/status':
                        device_id=self.authorize()
                        if not device_id:return self.respond(401,{'error':'unpaired_device'})
                        if not owner_logged_in():return self.respond(403,{'error':'pc_owner_offline'})
                        return self.respond(200,{'connected':True,'pc_name':socket.gethostname()[:64],
                                                 'pc_ip':lan_ip(),'device_id':device_id,
                                                 'last_seen_server_ms':now_ms()})
                    if path=='/api/health':return self.respond(200,{'ok':True,'service':'ParcelGuard PC Station V1.2','tls':False,'port':8766})
                    return self.respond(404,{'error':'LAN API only'})
                if path=='/api/auth/status':
                    session=session_for(self.headers.get('Cookie'))
                    return self.respond(200,{'authenticated':bool(session),'email':session['email'] if session else '',
                                             'csrf':session['csrf'] if session else ''})
                session=session_for(self.headers.get('Cookie'))
                if not session:
                    if path in ('/','/index.html','/login.html'):
                        return self.respond(200,(WEB/'login.html').read_bytes(),'text/html; charset=utf-8')
                    if path.startswith('/assets/') or path in ('/styles.css','/login.js'):
                        file=(WEB/path.lstrip('/')).resolve()
                        if file.is_relative_to(WEB.resolve()) and file.is_file():
                            return self.respond(200,file.read_bytes(),mimetypes.guess_type(file.name)[0] or 'application/octet-stream')
                    return self.respond(401,{'error':'ต้องเข้าสู่ระบบ Pro ก่อน'})
                if path=='/api/version':
                    return self.respond(200, {'version':APP_VERSION,'channel':'pilot','automatic_install':False})
                if path=='/api/update/check':
                    # Read-only version check. Never downloads or executes binaries.
                    try:
                        request=urllib.request.Request(UPDATE_MANIFEST_URL,headers={'Accept':'application/json','User-Agent':'ParcelGuardPC/1.4.0'})
                        with urllib.request.urlopen(request,timeout=6) as response:
                            if response.status!=200 or response.headers.get_content_type()!='application/json':
                                raise ValueError('ไม่พบไฟล์ประกาศเวอร์ชันที่ถูกต้อง')
                            manifest=json.loads(response.read(8192))
                        latest=str(manifest.get('version',''))
                        if not re.fullmatch(r'\d+\.\d+\.\d+',latest):
                            raise ValueError('ข้อมูลเวอร์ชันไม่ถูกต้อง')
                        current=tuple(map(int,APP_VERSION.split('.')))
                        newer=tuple(map(int,latest.split('.')))>current
                        return self.respond(200,{'current':APP_VERSION,'latest':latest,'update_available':newer,'manual_only':True})
                    except Exception:
                        return self.respond(200,{'current':APP_VERSION,'latest':None,'update_available':None,
                           'message':'ยังไม่สามารถตรวจเวอร์ชันออนไลน์ได้ โปรดลองใหม่ภายหลัง','manual_only':True})
                if path=='/api/health':return self.respond(200,{'ok':True,'service':'ParcelGuard PC Station V1.2','lan_ip':lan_ip(),'lan_enabled':self.server.lan_enabled})
                if path=='/api/pair/status':
                    with QR_LOCK:
                        remaining=max(0,int(QR_STATE['until']-time.monotonic()+0.99)) if QR_STATE['code'] else 0
                        last_result=QR_STATE['last_result']
                    return self.respond(200,{'lan_enabled':bool(self.server.lan_enabled),'lan_ip':lan_ip(),'remaining_seconds':remaining,'paired_devices':len(store.devices())-1,'last_pairing_result':last_result})
                if path=='/api/pair/qr':
                    if not getattr(self.server,'lan_enabled',False):return self.respond(400,{'error':'LAN ไม่ได้เปิด'})
                    with QR_LOCK:
                        code=QR_STATE['code'];valid=time.monotonic()<QR_STATE['until']
                    if not valid or not code:return self.respond(410,{'error':'QR หมดอายุ'})
                    try:
                        import qrcode
                        image=qrcode.make('PGPAIR1|%s|8766|%s'%(lan_ip(),code))
                        output=io.BytesIO();image.save(output,format='PNG')
                        return self.respond(200,output.getvalue(),'image/png')
                    except ImportError:
                        return self.respond(503,{'error':'ติดตั้ง qrcode และ pillow ก่อน'})
                if path=='/api/summary':return self.respond(200,store.summary())
                if path=='/api/bags':return self.respond(200,store.bags())
                if path=='/api/parcels':return self.respond(200,store.parcels(query.get('q',[''])[0],query.get('carrier',['all'])[0]))
                if path=='/api/devices':return self.respond(200,store.devices())
                if path=='/api/config':return self.respond(200,{'data_dir':str(store.data),'lan_api':'enabled' if self.server.lan_enabled else 'disabled','cloud':'not_connected','lan_ip':lan_ip()})
                if path.startswith('/api/media/'):
                    sha=path.split('/')[-1]
                    file=store.media_location(sha)
                    if not file:return self.respond(404,{'error':'ไม่พบไฟล์'})
                    return self.respond(200,file.read_bytes(), mimetypes.guess_type(file.name)[0] or 'application/octet-stream')
                if path=='/api/export/report.csv':
                    def sanitize(v):
                        s=str(v or '')
                        return "'"+s if s.startswith(('=','+','-','@')) else s
                    out=io.StringIO();writer=csv.writer(out)
                    writer.writerow(['bag','carrier','expected','scanned','missing','unexpected','status'])
                    for b in store.bags(): writer.writerow([sanitize(b['bag_id']),sanitize(b['carrier']),len(b['expected']),len(b['scanned']),len(b['missing']),len(b['extra']),'VERIFIED' if b['verified'] else 'REVIEW'])
                    return self.respond(200,('\ufeff'+out.getvalue()).encode('utf-8'),'text/csv; charset=utf-8',{'Content-Disposition':'attachment; filename="ParcelGuard-Report.csv"'})
                if path in ('/','/index.html'): path='/index.html'
                # Restrict requests to static assets inside WEB.
                rel=path.lstrip('/')
                f=(WEB/rel).resolve()
                if not f.is_relative_to(WEB.resolve()) or not f.is_file():return self.respond(404,{'error':'ไม่พบไฟล์'})
                return self.respond(200,f.read_bytes(),mimetypes.guess_type(f.name)[0] or 'application/octet-stream')
            except Exception as e:
                return self.respond(500,{'error':str(e)})
        def do_POST(self):
            parsed=urllib.parse.urlsplit(self.path)
            path=parsed.path
            if mode=='lan' and path not in ('/api/sync/archive','/api/pair/claim'):return self.respond(404,{'error':'LAN endpoint not found'})
            if mode=='local':
                origin=self.headers.get('Origin')
                if origin:
                    source=urllib.parse.urlsplit(origin)
                    if source.scheme!='http' or source.hostname not in ('127.0.0.1','localhost') or source.port!=self.server.server_address[1]:
                        return self.respond(403,{'error':'ไม่อนุญาต Origin นี้'})
            if mode=='local':
                # Cross-origin form posts are not allowed; AJAX from our localhost UI only.
                if self.headers.get('Sec-Fetch-Site','same-origin') not in ('same-origin','none'):
                    return self.respond(403,{'error':'origin blocked'})
                if path=='/api/auth/login':
                    try:
                        data=self.read_body()
                        if len(data)>4096:raise ValueError('ข้อมูลเข้าสู่ระบบใหญ่เกิน')
                        body=json.loads(data)
                        credentials=verify_commercial_login(body.get('email'),body.get('password'),store.data)
                        email=credentials['email']
                        cookie,record=new_session(email,credentials)
                        return self.respond(200,{'ok':True,'email':email,'csrf':record['csrf']},
                             extra={'Set-Cookie':'pg_session='+cookie+'; HttpOnly; SameSite=Strict; Path=/'})
                    except (ValueError,json.JSONDecodeError) as exc:
                        return self.respond(403,{'error':str(exc)})
                session=session_for(self.headers.get('Cookie'))
                if not session:return self.respond(401,{'error':'เข้าสู่ระบบ Pro ก่อน'})
                if not hmac.compare_digest(self.headers.get('X-PG-CSRF',''),session['csrf']):
                    return self.respond(403,{'error':'คำขอไม่ผ่านการตรวจสอบ CSRF'})
                if path=='/api/backup/create':
                    try:
                        return self.respond(200,store.backup_now())
                    except Exception as exc:
                        return self.respond(500,{'error':'สำรองข้อมูลไม่สำเร็จ: '+str(exc)})
                if path=='/api/auth/logout':
                    import http.cookies
                    jar=http.cookies.SimpleCookie()
                    try:
                        jar.load(self.headers.get('Cookie',''))
                        digest=hashlib.sha256(jar['pg_session'].value.encode()).hexdigest()
                        with AUTH_LOCK:SESSIONS.pop(digest,None)
                    except Exception:pass
                    return self.respond(200,{'ok':True},extra={'Set-Cookie':'pg_session=; HttpOnly; SameSite=Strict; Path=/; Max-Age=0'})
            try:
                if mode=='lan' and not owner_logged_in():
                    return self.respond(403,{'error':'pc_owner_not_logged_in'})
                if mode=='lan' and path=='/api/pair/claim':
                    body=self.read_body()
                    if len(body)>4096:raise ValueError('QR request ใหญ่เกิน')
                    obj=json.loads(body)
                    code=obj.get('code',''); name=obj.get('name','Android')
                    if not isinstance(code,str) or not isinstance(name,str):raise ValueError('QR ไม่ถูกต้อง')
                    with QR_LOCK:
                        if not QR_STATE['code'] or time.monotonic()>=QR_STATE['until']:
                            QR_STATE['last_result']='QR หมดอายุหรือถูกใช้แล้ว • สร้าง QR ใหม่'
                            print('[PAIR] expired / already claimed', flush=True)
                            return self.respond(410,{'error':'qr_expired_or_used'})
                        if not hmac.compare_digest(code,QR_STATE['code']):
                            QR_STATE['last_result']='รหัส QR ไม่ตรงกับ PC ตัวนี้ • ตรวจว่าไม่มีโปรแกรม PC อื่นเปิดอยู่'
                            print('[PAIR] QR code mismatch (different PC process or older QR)', flush=True)
                            return self.respond(409,{'error':'qr_code_mismatch'})
                        QR_STATE['code']='';QR_STATE['until']=0
                        QR_STATE['last_result']='Android จับคู่สำเร็จ • รอรับหลักฐานพัสดุ'
                    pair=store.connect_device(name[:60] or 'Android')
                    print('[PAIR] Android paired successfully', flush=True)
                    return self.respond(200,{'id':pair['id'],'token':pair['token'],'pc_name':socket.gethostname()[:64]})
                if mode=='lan':
                    device_id=self.authorize()
                    if not device_id:
                        print('[SYNC] unauthorized device token', flush=True)
                        return self.respond(401,{'error':'unauthorized'})
                    contents=self.read_body()
                    result=store.ingest_zip(contents,device_id)
                    print('[SYNC] imported=%s skipped=%s' % (result.get('imported',0),result.get('skipped',0)), flush=True)
                    return self.respond(200,{'status':'already_imported' if result.get('already_imported') else 'imported', 'imported':result.get('imported',0)})
                if path=='/api/pc/scan':
                    body=self.read_body()
                    if len(body)>36*1024*1024:raise ValueError('หลักฐานใหญ่เกิน')
                    payload=json.loads(body)
                    return self.respond(200,store.pc_scan(payload.get('tracking',''),payload.get('bag',''),payload.get('carrier','SPX'),payload.get('photo',''),payload.get('video','')))
                if path=='/api/pair/new':
                    # Localhost-only API (protected by strict origin check), never on LAN.
                    token=secrets.token_urlsafe(32)
                    with QR_LOCK:
                        QR_STATE['code']=token;QR_STATE['until']=time.monotonic()+90;QR_STATE['issued_at']=time.time();QR_STATE['last_result']='สร้าง QR ใหม่แล้ว • รอสแกนภายใน 90 วินาที'
                    ip=lan_ip()
                    return self.respond(200,{'pairing':'PGPAIR1|%s|8766|%s'%(ip,token),'ip':ip,'ttl':90,'lan':self.server.lan_enabled})
                if path=='/api/import-zip': return self.respond(200,store.ingest_zip(self.read_body()))
                if path=='/api/create-bag':
                    data=json.loads(self.read_body())
                    return self.respond(200,store.create_test_bag(data.get('bag_id'),data.get('carrier')))
                if path=='/api/import-expected':
                    key=urllib.parse.parse_qs(parsed.query).get('bag',[''])[0]
                    return self.respond(200,{'count':store.set_expected(key,self.read_body())})
                if path=='/api/devices/pair':
                    data=json.loads(self.read_body())
                    return self.respond(200,store.connect_device(data.get('name')))
                return self.respond(404,{'error':'Unknown endpoint'})
            except KeyError as e:return self.respond(404,{'error':str(e)})
            except (ValueError, zipfile.BadZipFile, json.JSONDecodeError) as e:return self.respond(400,{'error':str(e)})
            except Exception as e:return self.respond(500,{'error':'Internal error: '+str(e)})
    return Handler


def start(data,port=8765, lan=False, browser=True):
    store=Store(data)
    # Bind BOTH ports before starting threads. Prevent a half-open dashboard
    # with a stale/other Windows receiver already occupying port 8766.
    ui=None;private_lan=None
    try:
        ui=ThreadingHTTPServer(('127.0.0.1',port),make_handler(store,'local'))
        ui.lan_enabled=bool(lan)
        if lan:
            private_lan=ThreadingHTTPServer(('0.0.0.0',port+1),make_handler(store,'lan'))
    except OSError as e:
        if private_lan:private_lan.server_close()
        if ui:ui.server_close()
        store.close()
        raise RuntimeError('เริ่ม PC Station ไม่ได้: พอร์ต %d หรือ %d ถูกใช้อยู่ อาจมี ParcelGuard รุ่นเก่าเปิดค้าง กรุณาปิดทุกหน้าต่างโปรแกรมแล้วลองอีกครั้ง (%s)'%(port,port+1,e)) from e
    t=threading.Thread(target=ui.serve_forever,daemon=True);t.start()
    if private_lan:
        lt=threading.Thread(target=private_lan.serve_forever,daemon=True);lt.start()
        print('LAN ingestion enabled on http://%s:%d/api/sync/archive (HTTP not encrypted; private Wi-Fi only)'%(lan_ip(),port+1),flush=True)
    url='http://127.0.0.1:%d'%port
    print('ParcelGuard PC started:',url)
    print('Data directory:',data)
    print('Android V0.4.3 supports opt-in sync while app is open; use a trusted private LAN only.')
    if browser:webbrowser.open(url)
    return store,ui,private_lan


def main():
    p=argparse.ArgumentParser()
    p.add_argument('--lan',action='store_true',help='Enable token-protected LAN archive ingestion. HTTP is not encrypted; trusted private Wi-Fi only.')
    p.add_argument('--port',type=int,default=8765)
    p.add_argument('--no-browser',action='store_true')
    p.add_argument('--data-dir',default=str(DEFAULT_DATA))
    a=p.parse_args()
    store,ui,other=start(a.data_dir,a.port,a.lan,not a.no_browser)
    try:
        while True: threading.Event().wait(3600)
    except KeyboardInterrupt:pass
    finally:
        ui.shutdown()
        if other:other.shutdown()
        store.close()

if __name__=='__main__':main()
